from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from contextlib import asynccontextmanager
import logging
import time
from typing import Dict, Any

from app.api.routes import api_routes_router
from app.core.config import settings
from app.core.database import engine, Base

# Налаштування логування
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Управління життєвим циклом """
    # Startup
    logger.info("Запуск EliteSpace Properies API")

    # Створення таблиць у базі даних (для розробки)
    if settings.debug:
        logger.info("Створення таблиць бази даних...")
        Base.metadata.create_all(bind=engine)
        logger.info("Таблиці бази даних створені")

    logger.info("EliteSpace Properies API запущено успішно!")

    yield

    # Shutdown
    logger.info("Завершення роботи Real Estate API...")

# Створення FastAPI додатку
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="""
     **EliteSpace Properies API** - повнофункціональний API для управління нерухомістю

    ## Основний функціонал:

    * **Квартири** - управління квартирами та їх характеристиками
    * **Будівлі** - інформація про будівлі та комплекси
    * **Власники та орендарі** - управління контактами та профілями
    * **Оренда** - створення та управління договорами оренди
    * **Продаж** - обробка угод купівлі-продажу
    * **Платежі** - обробка та відстеження платежів
    * **Знижки та акції** - система знижок та промо-пропозицій
    * **Відгуки** - збір та управління відгуками клієнтів
    * **Підтримка** - система тікетів технічної підтримки
    * **Аналітика** - звіти та статистика по всіх операціях

    ## Особливості:

    * Повна підтримка CRUD операцій
    * Розширена фільтрація та пошук
    * Пагінація результатів
    * Валідація даних через Pydantic схеми
    * Асинхронна обробка запитів
    """,
    debug=settings.debug,
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Слід обмежити конкретними доменами
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Middleware для логування запитів
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Логування всіх HTTP запитів"""
    start_time = time.time()

    # Логування початку запиту
    logger.info(f"{request.method} {request.url.path} - Початок обробки")

    # Обробка запиту
    response = await call_next(request)

    # Розрахунок часу обробки
    process_time = time.time() - start_time

    # Логування завершення запиту
    logger.info(
        f"{request.method} {request.url.path} - "
        f"Статус: {response.status_code} - "
        f"Час: {process_time:.4f}s"
    )

    # Додавання заголовка з часом обробки
    response.headers["X-Process-Time"] = str(process_time)

    return response

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Обробник помилок валідації"""
    logger.warning(f"Помилка валідації для {request.url.path}: {exc.errors()}")

    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "detail": "Помилка валідації даних",
            "errors": exc.errors(),
            "message": "Перевірте правильність переданих даних"
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Загальний обробник помилок"""
    logger.error(f" Неочікувана помилка для {request.url.path}: {str(exc)}", exc_info=True)

    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "detail": "Внутрішня помилка сервера",
            "message": "Сталася неочікувана помилка. Спробуйте пізніше."
        }
    )

@app.get("/", tags=["root"])
async def root() -> Dict[str, Any]:
    """Головна сторінка API"""
    return {
        "message": "Ласкаво просимо до EliteSpace Properies API!",
        "version": settings.app_version,
        "status": "Працює",
        "docs": "/docs",
        "redoc": "/redoc",
        "api": "/api/routes"
    }
# Підключення API роутерів
app.include_router(api_routes_router, prefix="/api/routes")

if __name__ == "__main__":
    import uvicorn
    logger.info("Запуск EliteSpace Properies API сервера...")
    uvicorn.run(host="localhost",port=5432)