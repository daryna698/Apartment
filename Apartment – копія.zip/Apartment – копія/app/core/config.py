from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Database
    database_url: str = "postgresql+psycopg2://postgres:1111@localhost:5432/postgres"
    db_host: str = "localhost"
    db_port: int = 5432
    db_user: str = "postgres"
    db_password: str = "1111"
    db_name: str = "postgres"

    # Security
    secret_key: str = "your-super-secret-key-change-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30

    # App
    app_name: str = "Real Estate Rental API"
    app_version: str = "1.0.0"
    debug: bool = True

    # API
    api_routes_prefix: str = "/api/routes"

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()