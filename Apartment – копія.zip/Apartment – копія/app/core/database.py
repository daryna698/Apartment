from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from typing import Generator
from .config import settings

# Створення engine для PostgreSQL
engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
    pool_recycle=300,
    echo=settings.debug,
    pool_size=10,
    max_overflow=20
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Базова модель для всіх таблиць
Base = declarative_base()

# Metadata для alembic
metadata = MetaData()

def get_db() -> Generator[Session, None, None]:
    """Dependency для отримання DB сесії"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_tables():
    """Створення всіх таблиць"""
    Base.metadata.create_all(bind=engine)

def drop_tables():
    """Видалення всіх таблиць"""
    Base.metadata.drop_all(bind=engine)