from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import Optional
from .database import get_db
from .config import settings

# Security
security = HTTPBearer()

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):
    """Отримання поточного користувача з токену"""
    # Тут буде логіка перевірки JWT токену
    # Поки що заглушка
    return {"user_id": 1, "role": "admin"}