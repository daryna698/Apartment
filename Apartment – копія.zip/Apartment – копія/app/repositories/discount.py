from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_
from datetime import date
from app.models.discount import Discount
from app.schemas.discount import DiscountCreate, DiscountUpdate
from .base import BaseRepository


class DiscountRepository(BaseRepository[Discount, DiscountCreate, DiscountUpdate]):
    def __init__(self):
        super().__init__(Discount)

    def get_active_for_apartment(
            self,
            db: Session,
            apartment_id: int
    ) -> List[Discount]:
        today = date.today()
        return (
            db.query(Discount)
            .filter(
                and_(
                    Discount.apartment_id == apartment_id,
                    Discount.is_active == True,
                    Discount.valid_from <= today,
                    Discount.valid_to >= today
                )
            )
            .all()
        )

    def get_expired(self, db: Session) -> List[Discount]:
        today = date.today()
        return (
            db.query(Discount)
            .filter(
                and_(
                    Discount.valid_to < today,
                    Discount.is_active == True
                )
            )
            .all()
        )


discount_repo = DiscountRepository()