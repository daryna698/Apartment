from typing import List, Optional
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, func
from app.models.review import Review
from app.schemas.review import ReviewCreate, ReviewUpdate
from .base import BaseRepository


class ReviewRepository(BaseRepository[Review, ReviewCreate, ReviewUpdate]):
    def __init__(self):
        super().__init__(Review)

    def get_by_apartment(self, db: Session, apartment_id: int) -> List[Review]:
        return (
            db.query(Review)
            .options(joinedload(Review.renter))
            .filter(
                and_(
                    Review.apartment_id == apartment_id,
                    Review.is_approved == True
                )
            )
            .order_by(Review.created_at.desc())
            .all()
        )

    def get_by_renter(self, db: Session, renter_id: int) -> List[Review]:
        return (
            db.query(Review)
            .filter(Review.renter_id == renter_id)
            .order_by(Review.created_at.desc())
            .all()
        )

    def get_average_rating_for_apartment(
            self,
            db: Session,
            apartment_id: int
    ) -> Optional[float]:
        result = (
            db.query(func.avg(Review.rating))
            .filter(
                and_(
                    Review.apartment_id == apartment_id,
                    Review.is_approved == True
                )
            )
            .scalar()
        )
        return float(result) if result else None

    def get_pending_approval(self, db: Session) -> List[Review]:
        return (
            db.query(Review)
            .filter(Review.is_approved == False)
            .order_by(Review.created_at.desc())
            .all()
        )


review_repo = ReviewRepository()