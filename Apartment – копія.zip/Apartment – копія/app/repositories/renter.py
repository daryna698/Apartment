from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func
from app.models.renter import Renter
from .base import BaseRepository

class RenterRepository(BaseRepository[Renter]):
    def __init__(self, session: Session):
        super().__init__(Renter, session)

    def get_by_email(self, email: str) -> Optional[Renter]:
        return (self.session.query(Renter)
                .filter(Renter.email == email)
                .first())

    def get_by_phone(self, phone: str) -> Optional[Renter]:
        return (self.session.query(Renter)
                .filter(Renter.phone == phone)
                .first())

    def get_with_rentals(self, id: int) -> Optional[Renter]:
        return (self.session.query(Renter)
                .options(joinedload(Renter.rentals))
                .filter(Renter.id == id)
                .first())

    def search_by_name(self, name: str) -> List[Renter]:
        search_term = f"%{name}%"
        return (self.session.query(Renter)
                .filter(or_(
                    Renter.first_name.ilike(search_term),
                    Renter.last_name.ilike(search_term),
                    Renter.middle_name.ilike(search_term)
                ))
                .filter(Renter.is_active == True)
                .all())

    def get_active_renters(self) -> List[Renter]:
        from app.models.rental import Rental, RentalStatus
        return (self.session.query(Renter)
                .join(Rental)
                .filter(Rental.status == RentalStatus.ACTIVE)
                .distinct()
                .all())
