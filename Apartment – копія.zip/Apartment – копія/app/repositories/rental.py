from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, func, or_
from datetime import datetime, date, timedelta  # додаємо timedelta
from app.models.rental import Rental, RentalStatus
from .base import BaseRepository


class RentalRepository(BaseRepository[Rental]):
    def __init__(self, session: Session):
        super().__init__(Rental, session)

    def get_active_rentals(self) -> List[Rental]:
        return (self.session.query(Rental)
                .filter(Rental.status == RentalStatus.ACTIVE)
                .options(
            joinedload(Rental.apartment),
            joinedload(Rental.renter)
        )
                .all())

    def get_expiring_soon(self, days: int = 30) -> List[Rental]:
        future_date = datetime.now().date() + timedelta(days=days)
        return (self.session.query(Rental)
                .filter(and_(
            Rental.status == RentalStatus.ACTIVE,
            Rental.end_date <= future_date
        ))
                .options(
            joinedload(Rental.apartment),
            joinedload(Rental.renter)
        )
                .all())

    def get_by_renter(self, renter_id: int) -> List[Rental]:
        return (self.session.query(Rental)
                .filter(Rental.renter_id == renter_id)
                .options(joinedload(Rental.apartment))
                .all())

    def get_by_apartment(self, apartment_id: int) -> List[Rental]:
        return (self.session.query(Rental)
                .filter(Rental.apartment_id == apartment_id)
                .options(joinedload(Rental.renter))
                .all())

    def get_rental_history(self, apartment_id: int) -> List[Rental]:
        return (self.session.query(Rental)
                .filter(Rental.apartment_id == apartment_id)
                .options(joinedload(Rental.renter))
                .order_by(Rental.start_date.desc())
                .all())

    def get_monthly_revenue(self, year: int, month: int) -> Dict[str, Any]:
        from sqlalchemy import extract
        rentals = (self.session.query(Rental)
                   .filter(and_(
            extract('year', Rental.start_date) <= year,
            extract('month', Rental.start_date) <= month,
            or_(
                extract('year', Rental.end_date) >= year,
                extract('month', Rental.end_date) >= month,
                Rental.end_date.is_(None)
            )
        ))
                   .options(joinedload(Rental.apartment))
                   .all())

        total_revenue = sum(rental.monthly_rent for rental in rentals)
        return {
            "year": year,
            "month": month,
            "total_revenue": total_revenue,
            "active_rentals": len(rentals)
        }
