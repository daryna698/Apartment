from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func
from app.models.owner import Owner
from .base import BaseRepository

class OwnerRepository(BaseRepository[Owner]):
    def __init__(self, session: Session):
        super().__init__(Owner, session)

    def get_by_email(self, email: str) -> Optional[Owner]:
        return (self.session.query(Owner)
                .filter(Owner.email == email)
                .first())

    def get_by_phone(self, phone: str) -> Optional[Owner]:
        return (self.session.query(Owner)
                .filter(or_(Owner.phone == phone, Owner.alternative_phone == phone))
                .first())

    def get_with_apartments(self, id: int) -> Optional[Owner]:
        return (self.session.query(Owner)
                .options(joinedload(Owner.apartments))
                .filter(Owner.id == id)
                .first())

    def search_by_name(self, name: str) -> List[Owner]:
        search_term = f"%{name}%"
        return (self.session.query(Owner)
                .filter(or_(
                    Owner.first_name.ilike(search_term),
                    Owner.last_name.ilike(search_term),
                    Owner.middle_name.ilike(search_term)
                ))
                .filter(Owner.is_active == True)
                .all())

    def get_owners_with_multiple_properties(self) -> List[Owner]:
        from app.models.apartment import Apartment
        return (self.session.query(Owner)
                .join(Apartment)
                .group_by(Owner.id)
                .having(func.count(Apartment.id) > 1)
                .options(joinedload(Owner.apartments))
                .all())
