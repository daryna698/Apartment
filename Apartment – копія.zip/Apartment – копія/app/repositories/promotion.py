from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_
from datetime import date
from app.models.promotion import Promotion
from app.schemas.promotion import PromotionCreate, PromotionUpdate
from .base import BaseRepository


class PromotionRepository(BaseRepository[Promotion, PromotionCreate, PromotionUpdate]):
    def __init__(self):
        super().__init__(Promotion)

    def get_active_for_target_group(
            self,
            db: Session,
            target_group: str
    ) -> List[Promotion]:
        today = date.today()
        return (
            db.query(Promotion)
            .filter(
                and_(
                    Promotion.target_group == target_group,
                    Promotion.is_active == True,
                    Promotion.valid_from <= today,
                    Promotion.valid_to >= today
                )
            )
            .all()
        )

    def get_all_active(self, db: Session) -> List[Promotion]:
        today = date.today()
        return (
            db.query(Promotion)
            .filter(
                and_(
                    Promotion.is_active == True,
                    Promotion.valid_from <= today,
                    Promotion.valid_to >= today
                )
            )
            .all()
        )


promotion_repo = PromotionRepository()
