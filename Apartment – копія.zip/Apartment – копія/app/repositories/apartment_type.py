from typing import List, Optional
from sqlalchemy.orm import Session, joinedload
from app.models.apartment_type import ApartmentType
from app.schemas.apartment_type import ApartmentTypeCreate, ApartmentTypeUpdate
from app.repositories.base import BaseRepository


class ApartmentTypeRepository(BaseRepository[ApartmentType, ApartmentTypeCreate, ApartmentTypeUpdate]):
    """Репозиторій для роботи з типами квартир"""

    def __init__(self, session: Session):
        super().__init__(ApartmentType, session)

    def get_active_types(self, skip: int = 0, limit: int = 100) -> List[ApartmentType]:
        """Отримати активні типи квартир"""
        return (self.session.query(ApartmentType)
                .filter(ApartmentType.is_active == True)
                .order_by(ApartmentType.name)
                .offset(skip)
                .limit(limit)
                .all())

    def get_by_name(self, name: str) -> Optional[ApartmentType]:
        """Отримати тип квартири за назвою"""
        return (self.session.query(ApartmentType)
                .filter(ApartmentType.name == name)
                .first())

    def get_with_apartments(self, id: int) -> Optional[ApartmentType]:
        """Отримати тип квартири з пов'язаними квартирами"""
        return (self.session.query(ApartmentType)
                .options(joinedload(ApartmentType.apartments))
                .filter(ApartmentType.id == id)
                .first())

    def search_by_name(self, search_term: str, skip: int = 0, limit: int = 100) -> List[ApartmentType]:
        """Пошук типів квартир за назвою"""
        return (self.session.query(ApartmentType)
                .filter(ApartmentType.name.ilike(f"%{search_term}%"))
                .offset(skip)
                .limit(limit)
                .all())

    def get_filtered(self, is_active: Optional[bool] = None, search: Optional[str] = None,
                     skip: int = 0, limit: int = 100) -> List[ApartmentType]:
        """Отримати типи квартир з фільтрацією"""
        query = self.session.query(ApartmentType)

        if is_active is not None:
            query = query.filter(ApartmentType.is_active == is_active)

        if search:
            query = query.filter(ApartmentType.name.ilike(f"%{search}%"))

        return query.offset(skip).limit(limit).all()