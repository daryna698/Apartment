from typing import Generic, Type, TypeVar, List, Optional, Any, Dict
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from pydantic import BaseModel

# Типізація для моделей та схем
ModelType = TypeVar("ModelType")
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class BaseRepository(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    """Базовий репозиторій для всіх моделей"""

    def __init__(self, model: Type[ModelType], session: Session):
        self.model = model
        self.session = session

    def get_by_id(self, id: int) -> Optional[ModelType]:
        """Отримати об'єкт за ID"""
        return self.session.query(self.model).filter(self.model.id == id).first()

    def get_all(self, skip: int = 0, limit: int = 100) -> List[ModelType]:
        """Отримати всі об'єкти з пагінацією"""
        return (self.session.query(self.model)
                .offset(skip)
                .limit(limit)
                .all())

    def create(self, obj_data: CreateSchemaType) -> ModelType:
        """Створити новий об'єкт"""
        # Перетворюємо Pydantic модель в словник
        if hasattr(obj_data, 'dict'):
            obj_dict = obj_data.dict()
        elif hasattr(obj_data, 'model_dump'):
            obj_dict = obj_data.model_dump()
        else:
            obj_dict = obj_data.__dict__

        db_obj = self.model(**obj_dict)
        self.session.add(db_obj)
        self.session.commit()
        self.session.refresh(db_obj)
        return db_obj

    def update(self, db_obj: ModelType, obj_data: UpdateSchemaType) -> ModelType:
        """Оновити існуючий об'єкт"""
        # Перетворюємо Pydantic модель в словник, виключаючи не встановлені поля
        if hasattr(obj_data, 'dict'):
            obj_dict = obj_data.dict(exclude_unset=True)
        elif hasattr(obj_data, 'model_dump'):
            obj_dict = obj_data.model_dump(exclude_unset=True)
        else:
            obj_dict = {k: v for k, v in obj_data.__dict__.items() if v is not None}

        for field, value in obj_dict.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        self.session.commit()
        self.session.refresh(db_obj)
        return db_obj

    def delete(self, id: int) -> bool:
        """Видалити об'єкт за ID"""
        db_obj = self.get_by_id(id)
        if db_obj:
            self.session.delete(db_obj)
            self.session.commit()
            return True
        return False

    def count(self) -> int:
        """Підрахунок кількості записів"""
        return self.session.query(self.model).count()

    def exists(self, id: int) -> bool:
        """Перевірити чи існує об'єкт з таким ID"""
        return self.session.query(self.model).filter(self.model.id == id).first()