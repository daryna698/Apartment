from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func
from app.models.support_ticket import SupportTicket, TicketStatus, TicketPriority
from .base import BaseRepository


class SupportTicketRepository(BaseRepository[SupportTicket]):
    def __init__(self, session: Session):
        super().__init__(SupportTicket, session)

    def get_with_relations(self, id: int) -> Optional[SupportTicket]:
        """Отримати тікет з усіма зв'язками"""
        return (self.session.query(SupportTicket)
                .options(joinedload(SupportTicket.user))
                .filter(SupportTicket.id == id)
                .first())

    def get_by_status(self, status: TicketStatus) -> List[SupportTicket]:
        """Отримати тікети за статусом"""
        return (self.session.query(SupportTicket)
                .filter(SupportTicket.status == status)
                .order_by(SupportTicket.created_at.desc())
                .all())

    def get_by_priority(self, priority: TicketPriority) -> List[SupportTicket]:
        """Отримати тікети за пріоритетом"""
        return (self.session.query(SupportTicket)
                .filter(SupportTicket.priority == priority)
                .order_by(SupportTicket.created_at.desc())
                .all())

    def get_by_user(self, user_id: int) -> List[SupportTicket]:
        """Отримати тікети користувача"""
        return (self.session.query(SupportTicket)
                .filter(SupportTicket.user_id == user_id)
                .order_by(SupportTicket.created_at.desc())
                .all())

    def get_open_tickets(self) -> List[SupportTicket]:
        """Отримати відкриті тікети"""
        return (self.session.query(SupportTicket)
                .filter(SupportTicket.status.in_([
            TicketStatus.OPEN,
            TicketStatus.IN_PROGRESS
        ]))
                .order_by(SupportTicket.priority.desc(), SupportTicket.created_at.asc())
                .all())

    def get_statistics(self) -> Dict[str, Any]:
        """Отримати статистику тікетів"""
        total_tickets = self.session.query(SupportTicket).count()

        status_stats = (self.session.query(
            SupportTicket.status,
            func.count(SupportTicket.id).label('count')
        )
                        .group_by(SupportTicket.status)
                        .all())

        priority_stats = (self.session.query(
            SupportTicket.priority,
            func.count(SupportTicket.id).label('count')
        )
                          .group_by(SupportTicket.priority)
                          .all())

        return {
            "total_tickets": total_tickets,
            "by_status": {stat.status.value: stat.count for stat in status_stats},
            "by_priority": {stat.priority.value: stat.count for stat in priority_stats}
        }