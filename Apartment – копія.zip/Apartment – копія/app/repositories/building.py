from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func
from app.models.building import Building
from .base import BaseRepository


class BuildingRepository(BaseRepository[Building]):
    def __init__(self, session: Session):
        super().__init__(Building, session)

    def get_with_apartments(self, id: int) -> Optional[Building]:
        return (self.session.query(Building)
                .options(joinedload(Building.apartments))
                .filter(Building.id == id)
                .first())

    def search_by_location(self, city: str = None, district: str = None) -> List[Building]:
        query = self.session.query(Building).filter(Building.is_active == True)

        if city:
            query = query.filter(Building.city.ilike(f"%{city}%"))
        if district:
            query = query.filter(Building.district.ilike(f"%{district}%"))

        return query.all()

    def get_buildings_with_amenities(self,
                                     elevator: bool = None,
                                     parking: bool = None,
                                     security: bool = None) -> List[Building]:
        query = self.session.query(Building).filter(Building.is_active == True)

        if elevator is not None:
            query = query.filter(Building.elevator == elevator)
        if parking is not None:
            query = query.filter(Building.parking == parking)
        if security is not None:
            query = query.filter(Building.security == security)

        return query.all()

    def get_statistics(self) -> Dict[str, Any]:
        total_buildings = self.session.query(Building).filter(Building.is_active == True).count()
        cities_count = self.session.query(Building.city).distinct().count()

        amenities_stats = (self.session.query(
            func.sum(Building.elevator.cast('integer')).label('elevator_count'),
            func.sum(Building.parking.cast('integer')).label('parking_count'),
            func.sum(Building.security.cast('integer')).label('security_count')
        ).filter(Building.is_active == True).first())

        return {
            "total_buildings": total_buildings,
            "cities_count": cities_count,
            "with_elevator": amenities_stats.elevator_count or 0,
            "with_parking": amenities_stats.parking_count or 0,
            "with_security": amenities_stats.security_count or 0
        }