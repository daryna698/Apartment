from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, extract, func
from datetime import datetime, date
from app.models.sale import Sale, SaleStatus
from .base import BaseRepository


class SaleRepository(BaseRepository[Sale]):
    def __init__(self, session: Session):
        super().__init__(Sale, session)

    def get_with_relations(self, id: int) -> Optional[Sale]:
        return (self.session.query(Sale)
                .options(
            joinedload(Sale.apartment),
            joinedload(Sale.buyer),
            joinedload(Sale.seller)
        )
                .filter(Sale.id == id)
                .first())

    def get_completed_sales(self) -> List[Sale]:
        return (self.session.query(Sale)
                .filter(Sale.status == SaleStatus.COMPLETED)
                .options(
            joinedload(Sale.apartment),
            joinedload(Sale.buyer),
            joinedload(Sale.seller)
        )
                .all())

    def get_pending_sales(self) -> List[Sale]:
        return (self.session.query(Sale)
                .filter(Sale.status == SaleStatus.PENDING)
                .options(
            joinedload(Sale.apartment),
            joinedload(Sale.buyer),
            joinedload(Sale.seller)
        )
                .all())

    def get_by_buyer(self, buyer_id: int) -> List[Sale]:
        return (self.session.query(Sale)
                .filter(Sale.buyer_id == buyer_id)
                .options(joinedload(Sale.apartment))
                .all())

    def get_by_seller(self, seller_id: int) -> List[Sale]:
        return (self.session.query(Sale)
                .filter(Sale.seller_id == seller_id)
                .options(joinedload(Sale.apartment))
                .all())

    def get_sales_statistics(self, year: int = None) -> Dict[str, Any]:
        query = self.session.query(Sale).filter(Sale.status == SaleStatus.COMPLETED)

        if year:
            query = query.filter(extract('year', Sale.sale_date) == year)

        sales = query.all()

        if not sales:
            return {
                "total_sales": 0,
                "total_revenue": 0,
                "average_price": 0,
                "min_price": 0,
                "max_price": 0
            }

        total_revenue = sum(sale.final_price for sale in sales)
        prices = [sale.final_price for sale in sales]

        return {
            "total_sales": len(sales),
            "total_revenue": total_revenue,
            "average_price": total_revenue / len(sales),
            "min_price": min(prices),
            "max_price": max(prices)
        }
