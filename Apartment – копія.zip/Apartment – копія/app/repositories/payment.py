from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func, extract
from datetime import datetime, date
from app.models.payment import Payment, PaymentStatus, PaymentType
from .base import BaseRepository


class PaymentRepository(BaseRepository[Payment]):
    def __init__(self, session: Session):
        super().__init__(Payment, session)

    def get_with_relations(self, id: int) -> Optional[Payment]:
        """Отримати платіж з усіма зв'язками"""
        return (self.session.query(Payment)
                .options(
            joinedload(Payment.rental),
            joinedload(Payment.sale)
        )
                .filter(Payment.id == id)
                .first())

    def get_by_rental(self, rental_id: int) -> List[Payment]:
        """Отримати платежі за орендою"""
        return (self.session.query(Payment)
                .filter(Payment.rental_id == rental_id)
                .order_by(Payment.payment_date.desc())
                .all())

    def get_by_sale(self, sale_id: int) -> List[Payment]:
        """Отримати платежі за продажем"""
        return (self.session.query(Payment)
                .filter(Payment.sale_id == sale_id)
                .order_by(Payment.payment_date.desc())
                .all())

    def get_by_status(self, status: PaymentStatus) -> List[Payment]:
        """Отримати платежі за статусом"""
        return (self.session.query(Payment)
                .filter(Payment.status == status)
                .order_by(Payment.payment_date.desc())
                .all())

    def get_overdue_payments(self) -> List[Payment]:
        """Отримати прострочені платежі"""
        current_date = datetime.now().date()
        return (self.session.query(Payment)
                .filter(and_(
            Payment.status == PaymentStatus.PENDING,
            Payment.due_date < current_date
        ))
                .options(joinedload(Payment.rental))
                .all())

    def get_monthly_revenue(self, year: int, month: int) -> Dict[str, Any]:
        """Отримати місячний дохід"""
        payments = (self.session.query(Payment)
                    .filter(and_(
            Payment.status == PaymentStatus.COMPLETED,
            extract('year', Payment.payment_date) == year,
            extract('month', Payment.payment_date) == month
        ))
                    .all())

        total_revenue = sum(payment.amount for payment in payments)
        rental_revenue = sum(payment.amount for payment in payments if payment.payment_type == PaymentType.RENT)
        sale_revenue = sum(payment.amount for payment in payments if payment.payment_type == PaymentType.SALE)

        return {
            "year": year,
            "month": month,
            "total_revenue": total_revenue,
            "rental_revenue": rental_revenue,
            "sale_revenue": sale_revenue,
            "total_payments": len(payments)
        }