from typing import List, Optional
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_
from decimal import Decimal
from app.models.apartment import Apartment
from app.schemas.apartment import ApartmentCreate, ApartmentUpdate
from .base import BaseRepository


class ApartmentRepository(BaseRepository[Apartment, ApartmentCreate, ApartmentUpdate]):
    def __init__(self, session: Session):
        super().__init__(Apartment, session)

    def get_with_details(self, db: Session, id: int) -> Optional[Apartment]:
        return (
            db.query(Apartment)
            .options(
                joinedload(Apartment.building),
                joinedload(Apartment.apartment_type),
                joinedload(Apartment.owner)
            )
            .filter(Apartment.id == id)
            .first()
        )

    def get_multi_with_details(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Apartment]:
        return (
            db.query(Apartment)
            .options(
                joinedload(Apartment.building),
                joinedload(Apartment.apartment_type),
                joinedload(Apartment.owner)
            )
            .offset(skip)
            .limit(limit)
            .all()
        )

    def get_available_for_rent(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Apartment]:
        return (
            db.query(Apartment)
            .filter(
                and_(
                    Apartment.is_available_for_rent == True,
                    Apartment.is_active == True
                )
            )
            .offset(skip)
            .limit(limit)
            .all()
        )

    def get_available_for_sale(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Apartment]:
        return (
            db.query(Apartment)
            .filter(
                and_(
                    Apartment.is_available_for_sale == True,
                    Apartment.is_active == True
                )
            )
            .offset(skip)
            .limit(limit)
            .all()
        )

    def get_by_building(self, db: Session, building_id: int) -> List[Apartment]:
        return (
            db.query(Apartment)
            .filter(
                and_(
                    Apartment.building_id == building_id,
                    Apartment.is_active == True
                )
            )
            .all()
        )

    def get_by_owner(self, db: Session, owner_id: int) -> List[Apartment]:
        return (
            db.query(Apartment)
            .filter(
                and_(
                    Apartment.owner_id == owner_id,
                    Apartment.is_active == True
                )
            )
            .all()
        )

    def search_by_filters(
            self,
            db: Session,
            *,
            min_price: Optional[Decimal] = None,
            max_price: Optional[Decimal] = None,
            min_area: Optional[Decimal] = None,
            max_area: Optional[Decimal] = None,
            room_count: Optional[int] = None,
            apartment_type_id: Optional[int] = None,
            building_id: Optional[int] = None,
            available_for_rent: Optional[bool] = None,
            available_for_sale: Optional[bool] = None
    ) -> List[Apartment]:
        query = db.query(Apartment).filter(Apartment.is_active == True)

        if min_price is not None:
            query = query.filter(
                or_(
                    Apartment.rent_price >= min_price,
                    Apartment.sale_price >= min_price
                )
            )

        if max_price is not None:
            query = query.filter(
                or_(
                    Apartment.rent_price <= max_price,
                    Apartment.sale_price <= max_price
                )
            )

        if min_area is not None:
            query = query.filter(Apartment.area >= min_area)

        if max_area is not None:
            query = query.filter(Apartment.area <= max_area)

        if room_count is not None:
            query = query.filter(Apartment.room_count == room_count)

        if apartment_type_id is not None:
            query = query.filter(Apartment.apartment_type_id == apartment_type_id)

        if building_id is not None:
            query = query.filter(Apartment.building_id == building_id)

        if available_for_rent is not None:
            query = query.filter(Apartment.is_available_for_rent == available_for_rent)

        if available_for_sale is not None:
            query = query.filter(Apartment.is_available_for_sale == available_for_sale)

        return query.all()
