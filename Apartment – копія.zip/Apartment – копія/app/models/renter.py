from sqlalchemy import String, DateTime, Boolean, Text, Date, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional, List
from datetime import datetime, date


class Renter(Base):
    __tablename__ = "renters"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Personal info
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    middle_name: Mapped[Optional[str]] = mapped_column(String(100))
    birth_date: Mapped[Optional[date]] = mapped_column(Date)

    # Contact info
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    phone: Mapped[str] = mapped_column(String(20), nullable=False)
    alternative_phone: Mapped[Optional[str]] = mapped_column(String(20))

    # Address
    current_address: Mapped[Optional[str]] = mapped_column(String(500))
    city: Mapped[Optional[str]] = mapped_column(String(100))

    # Work info
    workplace: Mapped[Optional[str]] = mapped_column(String(200))
    position: Mapped[Optional[str]] = mapped_column(String(100))
    monthly_income: Mapped[Optional[int]] = mapped_column(Integer)  # в копійках

    # Additional info
    notes: Mapped[Optional[str]] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    rentals: Mapped[List["Rental"]] = relationship("Rental", back_populates="renter")
    sales: Mapped[List["Sale"]] = relationship("Sale", back_populates="buyer")
    reviews: Mapped[List["Review"]] = relationship("Review", back_populates="renter")
    support_tickets: Mapped[List["SupportTicket"]] = relationship("SupportTicket", back_populates="renter")

    @property
    def full_name(self):
        parts = [self.first_name]
        if self.middle_name:
            parts.append(self.middle_name)
        parts.append(self.last_name)
        return " ".join(parts)

    def __repr__(self):
        return f"<Renter(id={self.id}, name='{self.full_name}')>"