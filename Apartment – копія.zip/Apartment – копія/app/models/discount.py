from sqlalchemy import String, DateTime, Boolean, Text, Enum, Integer
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional
from datetime import datetime
import enum


class DiscountType(enum.Enum):
    PERCENTAGE = "percentage"
    FIXED_AMOUNT = "fixed_amount"


class Discount(Base):
    __tablename__ = "discounts"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Discount details
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    discount_type: Mapped[DiscountType] = mapped_column(Enum(DiscountType), nullable=False)
    value: Mapped[int] = mapped_column(Integer, nullable=False)  # відсоток * 100 або сума в копійках

    # Validity period
    start_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    end_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    # Usage limits
    max_uses: Mapped[Optional[int]] = mapped_column(Integer)  # максимальна кількість використань
    current_uses: Mapped[int] = mapped_column(Integer, default=0)

    # Conditions
    min_rental_period: Mapped[Optional[int]] = mapped_column(Integer)  # мінімальний період оренди в місяцях
    min_apartment_price: Mapped[Optional[int]] = mapped_column(Integer)  # мінімальна ціна квартири в копійках

    # Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    def __repr__(self):
        return f"<Discount(id={self.id}, name='{self.name}')>"
