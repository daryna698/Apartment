from sqlalchemy import String, DateTime, Boolean, ForeignKey, Text, Enum, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional, List
from datetime import datetime
import enum


class RentalStatus(enum.Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    TERMINATED = "terminated"
    PENDING = "pending"


class Rental(Base):
    __tablename__ = "rentals"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Rental details
    start_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    end_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    monthly_rent: Mapped[int] = mapped_column(Integer, nullable=False)  # в копійках
    deposit: Mapped[int] = mapped_column(Integer, default=0)  # застава в копійках
    utilities_cost: Mapped[int] = mapped_column(Integer, default=0)  # комунальні в копійках

    # Status
    status: Mapped[RentalStatus] = mapped_column(Enum(RentalStatus), default=RentalStatus.PENDING, index=True)

    # Contract details
    contract_number: Mapped[Optional[str]] = mapped_column(String(50), unique=True)
    contract_date: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # Additional terms
    pets_allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    smoking_allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    guests_allowed: Mapped[bool] = mapped_column(Boolean, default=True)

    # Notes
    notes: Mapped[Optional[str]] = mapped_column(Text)
    termination_reason: Mapped[Optional[str]] = mapped_column(Text)

    # Foreign Keys
    apartment_id: Mapped[int] = mapped_column(ForeignKey("apartments.id"), nullable=False)
    renter_id: Mapped[int] = mapped_column(ForeignKey("renters.id"), nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    apartment: Mapped["Apartment"] = relationship("Apartment", back_populates="rentals")
    renter: Mapped["Renter"] = relationship("Renter", back_populates="rentals")
    payments: Mapped[List["Payment"]] = relationship("Payment", back_populates="rental")

    @property
    def total_monthly_cost(self):
        return self.monthly_rent + self.utilities_cost

    def __repr__(self):
        return f"<Rental(id={self.id}, apartment_id={self.apartment_id}, status='{self.status.value}')>"