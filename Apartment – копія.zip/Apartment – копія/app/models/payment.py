from sqlalchemy import String, DateTime, Boolean, ForeignKey, Text, Enum, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional
from datetime import datetime
import enum


class PaymentType(enum.Enum):
    RENT = "rent"
    DEPOSIT = "deposit"
    UTILITIES = "utilities"
    PENALTY = "penalty"
    REFUND = "refund"


class PaymentStatus(enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class PaymentMethod(enum.Enum):
    CASH = "cash"
    BANK_TRANSFER = "bank_transfer"
    CARD = "card"
    ONLINE = "online"


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Payment details
    amount: Mapped[int] = mapped_column(Integer, nullable=False)  # сума в копійках
    payment_type: Mapped[PaymentType] = mapped_column(Enum(PaymentType), nullable=False)
    payment_method: Mapped[PaymentMethod] = mapped_column(Enum(PaymentMethod), nullable=False)

    # Dates
    due_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    payment_date: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # Status
    status: Mapped[PaymentStatus] = mapped_column(Enum(PaymentStatus), default=PaymentStatus.PENDING, index=True)

    # Transaction details
    transaction_id: Mapped[Optional[str]] = mapped_column(String(100), unique=True)
    reference_number: Mapped[Optional[str]] = mapped_column(String(100))

    # Notes
    description: Mapped[Optional[str]] = mapped_column(Text)
    notes: Mapped[Optional[str]] = mapped_column(Text)

    # Foreign Keys
    rental_id: Mapped[int] = mapped_column(ForeignKey("rentals.id"), nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    rental: Mapped["Rental"] = relationship("Rental", back_populates="payments")

    def __repr__(self):
        return f"<Payment(id={self.id}, amount={self.amount}, status='{self.status.value}')>"
