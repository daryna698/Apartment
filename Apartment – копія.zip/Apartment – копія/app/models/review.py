from sqlalchemy import String, DateTime, ForeignKey, Text, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional
from datetime import datetime


class Review(Base):
    __tablename__ = "reviews"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Review details
    rating: Mapped[int] = mapped_column(Integer, nullable=False)  # оцінка від 1 до 5
    title: Mapped[Optional[str]] = mapped_column(String(200))
    comment: Mapped[Optional[str]] = mapped_column(Text)

    # Review aspects
    cleanliness_rating: Mapped[Optional[int]] = mapped_column(Integer)  # чистота
    location_rating: Mapped[Optional[int]] = mapped_column(Integer)  # розташування
    value_rating: Mapped[Optional[int]] = mapped_column(Integer)  # ціна/якість
    communication_rating: Mapped[Optional[int]] = mapped_column(Integer)  # спілкування з власником

    # Response from owner
    owner_response: Mapped[Optional[str]] = mapped_column(Text)
    response_date: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # Foreign Keys
    apartment_id: Mapped[int] = mapped_column(ForeignKey("apartments.id"), nullable=False)
    renter_id: Mapped[int] = mapped_column(ForeignKey("renters.id"), nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    apartment: Mapped["Apartment"] = relationship("Apartment", back_populates="reviews")
    renter: Mapped["Renter"] = relationship("Renter", back_populates="reviews")

    @property
    def average_rating(self):
        ratings = [r for r in [self.cleanliness_rating, self.location_rating,
                               self.value_rating, self.communication_rating] if r is not None]
        return sum(ratings) / len(ratings) if ratings else self.rating

    def __repr__(self):
        return f"<Review(id={self.id}, rating={self.rating}, apartment_id={self.apartment_id})>"