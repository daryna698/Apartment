from sqlalchemy import String, Text, Float, Boolean, DateTime, ForeignKey, Enum, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional, List
from datetime import datetime
import enum


class ApartmentStatus(enum.Enum):
    AVAILABLE = "available"
    RENTED = "rented"
    SOLD = "sold"
    MAINTENANCE = "maintenance"
    RESERVED = "reserved"


class Apartment(Base):
    __tablename__ = "apartments"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Basic info
    number: Mapped[str] = mapped_column(String(20), nullable=False)
    floor: Mapped[int] = mapped_column(Integer, nullable=False)
    rooms_count: Mapped[int] = mapped_column(Integer, nullable=False)

    # Measurements
    total_area: Mapped[float] = mapped_column(Float, nullable=False)  # загальна площа в м²
    living_area: Mapped[Optional[float]] = mapped_column(Float)  # житлова площа в м²
    kitchen_area: Mapped[Optional[float]] = mapped_column(Float)  # площа кухні в м²

    # Features
    bathroom_count: Mapped[int] = mapped_column(Integer, default=1)
    balcony: Mapped[bool] = mapped_column(Boolean, default=False)
    loggia: Mapped[bool] = mapped_column(Boolean, default=False)
    separate_bathroom: Mapped[bool] = mapped_column(Boolean, default=False)

    # Condition and amenities
    renovation_type: Mapped[Optional[str]] = mapped_column(String(50))  # без ремонту, косметичний, євроремонт
    furnished: Mapped[bool] = mapped_column(Boolean, default=False)
    appliances: Mapped[Optional[str]] = mapped_column(Text)  # список техніки

    # Pricing
    rent_price: Mapped[Optional[int]] = mapped_column(Integer)  # ціна оренди в копійках на місяць
    sale_price: Mapped[Optional[int]] = mapped_column(Integer)  # ціна продажу в копійках
    utilities_included: Mapped[bool] = mapped_column(Boolean, default=False)

    # Status
    status: Mapped[ApartmentStatus] = mapped_column(Enum(ApartmentStatus), default=ApartmentStatus.AVAILABLE,
                                                    index=True)

    # Description and notes
    description: Mapped[Optional[str]] = mapped_column(Text)
    notes: Mapped[Optional[str]] = mapped_column(Text)

    # Images
    images: Mapped[Optional[str]] = mapped_column(Text)  # JSON масив з URL зображень

    # Foreign Keys
    building_id: Mapped[int] = mapped_column(ForeignKey("buildings.id"), nullable=False)
    owner_id: Mapped[int] = mapped_column(ForeignKey("owners.id"), nullable=False)
    apartment_type_id: Mapped[int] = mapped_column(ForeignKey("apartment_types.id"), nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    building: Mapped["Building"] = relationship("Building", back_populates="apartments")
    owner: Mapped["Owner"] = relationship("Owner", back_populates="apartments")
    apartment_type: Mapped["ApartmentType"] = relationship("ApartmentType", back_populates="apartments")
    rentals: Mapped[List["Rental"]] = relationship("Rental", back_populates="apartment")
    sales: Mapped[List["Sale"]] = relationship("Sale", back_populates="apartment")
    reviews: Mapped[List["Review"]] = relationship("Review", back_populates="apartment")

    @property
    def full_address(self):
        return f"{self.building.address}, кв. {self.number}"

    def __repr__(self):
        return f"<Apartment(id={self.id}, address='{self.full_address}')>"