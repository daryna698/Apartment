from sqlalchemy import String, DateTime, Boolean, Text, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional
from datetime import datetime


class Promotion(Base):
    __tablename__ = "promotions"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Promotion details
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)

    # Validity period
    start_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    end_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    # Targeting
    target_apartment_type: Mapped[Optional[str]] = mapped_column(String(100))
    target_city: Mapped[Optional[str]] = mapped_column(String(100))
    target_price_range_min: Mapped[Optional[int]] = mapped_column(Integer)
    target_price_range_max: Mapped[Optional[int]] = mapped_column(Integer)

    # Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Associated discount
    discount_id: Mapped[Optional[int]] = mapped_column(ForeignKey("discounts.id"))

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    discount: Mapped[Optional["Discount"]] = relationship("Discount")

    def __repr__(self):
        return f"<Promotion(id={self.id}, title='{self.title}')>"
