from sqlalchemy import DateTime, Boolean, ForeignKey, Text, Enum, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base
from typing import Optional
from datetime import datetime
import enum


class SaleStatus(enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class Sale(Base):
    __tablename__ = "sales"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    # Sale details
    sale_price: Mapped[int] = mapped_column(Integer, nullable=False)  # ціна в копійках
    sale_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    contract_date: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # Status
    status: Mapped[SaleStatus] = mapped_column(Enum(SaleStatus), default=SaleStatus.PENDING, index=True)

    # Commission
    commission_rate: Mapped[int] = mapped_column(Integer, default=0)  # відсоток комісії * 100 (наприклад, 500 = 5%)
    commission_amount: Mapped[int] = mapped_column(Integer, default=0)  # сума комісії в копійках

    # Notes
    notes: Mapped[Optional[str]] = mapped_column(Text)
    cancellation_reason: Mapped[Optional[str]] = mapped_column(Text)

    # Foreign Keys
    apartment_id: Mapped[int] = mapped_column(ForeignKey("apartments.id"), nullable=False)
    seller_id: Mapped[int] = mapped_column(ForeignKey("owners.id"), nullable=False)
    buyer_id: Mapped[int] = mapped_column(ForeignKey("renters.id"), nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    apartment: Mapped["Apartment"] = relationship("Apartment", back_populates="sales")
    seller: Mapped["Owner"] = relationship("Owner", back_populates="sales")
    buyer: Mapped["Renter"] = relationship("Renter", back_populates="sales")

    def __repr__(self):
        return f"<Sale(id={self.id}, apartment_id={self.apartment_id}, status='{self.status.value}')>"