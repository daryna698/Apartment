from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date
from decimal import Decimal
from app.core.database import get_db
from app.schemas.discount import DiscountCreate, DiscountUpdate, DiscountResponse
from app.services.discount import DiscountService

router = APIRouter(prefix="/discounts", tags=["Знижки"])

@router.post("/", response_model=DiscountResponse, status_code=201)
async def create_discount(
    discount_data: DiscountCreate,
    db: Session = Depends(get_db)
):
    """Створити нову знижку"""
    service = DiscountService(db)
    return await service.create_discount(discount_data)

@router.get("/", response_model=List[DiscountResponse])
async def get_discounts(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    is_active: Optional[bool] = Query(None, description="Активні знижки"),
    discount_type: Optional[str] = Query(None, description="Тип знижки"),
    min_amount: Optional[Decimal] = Query(None, description="Мінімальна сума знижки"),
    valid_from: Optional[date] = Query(None, description="Дійсна від"),
    valid_to: Optional[date] = Query(None, description="Дійсна до"),
    db: Session = Depends(get_db)
):
    """Отримати список знижок"""
    service = DiscountService(db)
    return await service.get_discounts(
        skip=skip, limit=limit, is_active=is_active,
        discount_type=discount_type, min_amount=min_amount,
        valid_from=valid_from, valid_to=valid_to
    )

@router.get("/{discount_id}", response_model=DiscountResponse)
async def get_discount(
    discount_id: int,
    db: Session = Depends(get_db)
):
    """Отримати знижку по ID"""
    service = DiscountService(db)
    discount = await service.get_discount(discount_id)
    if not discount:
        raise HTTPException(status_code=404, detail="Знижку не знайдено")
    return discount

@router.put("/{discount_id}", response_model=DiscountResponse)
async def update_discount(
    discount_id: int,
    discount_data: DiscountUpdate,
    db: Session = Depends(get_db)
):
    """Оновити знижку"""
    service = DiscountService(db)
    discount = await service.update_discount(discount_id, discount_data)
    if not discount:
        raise HTTPException(status_code=404, detail="Знижку не знайдено")
    return discount

@router.delete("/{discount_id}")
async def delete_discount(
    discount_id: int,
    db: Session = Depends(get_db)
):
    """Видалити знижку"""
    service = DiscountService(db)
    success = await service.delete_discount(discount_id)
    if not success:
        raise HTTPException(status_code=404, detail="Знижку не знайдено")
    return {"message": "Знижку успішно видалено"}

@router.patch("/{discount_id}/activate")
async def activate_discount(
    discount_id: int,
    db: Session = Depends(get_db)
):
    """Активувати знижку"""
    service = DiscountService(db)
    discount = await service.activate_discount(discount_id)
    if not discount:
        raise HTTPException(status_code=404, detail="Знижку не знайдено")
    return discount

@router.patch("/{discount_id}/deactivate")
async def deactivate_discount(
    discount_id: int,
    db: Session = Depends(get_db)
):
    """Деактивувати знижку"""
    service = DiscountService(db)
    discount = await service.deactivate_discount(discount_id)
    if not discount:
        raise HTTPException(status_code=404, detail="Знижку не знайдено")
    return discount
