from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date
from decimal import Decimal
from app.core.database import get_db
from app.schemas.payment import PaymentCreate, PaymentUpdate, PaymentResponse
from app.services.payment import PaymentService

router = APIRouter(prefix="/payments", tags=["Платежі"])

@router.post("/", response_model=PaymentResponse, status_code=201)
async def create_payment(
    payment_data: PaymentCreate,
    db: Session = Depends(get_db)
):
    """Створити новий платіж"""
    service = PaymentService(db)
    return await service.create_payment(payment_data)

@router.get("/", response_model=List[PaymentResponse])
async def get_payments(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    rental_id: Optional[int] = Query(None, description="ID оренди"),
    sale_id: Optional[int] = Query(None, description="ID продажу"),
    payment_type: Optional[str] = Query(None, description="Тип платежу"),
    status: Optional[str] = Query(None, description="Статус платежу"),
    amount_from: Optional[Decimal] = Query(None, description="Сума від"),
    amount_to: Optional[Decimal] = Query(None, description="Сума до"),
    payment_date_from: Optional[date] = Query(None, description="Дата платежу від"),
    payment_date_to: Optional[date] = Query(None, description="Дата платежу до"),
    db: Session = Depends(get_db)
):
    """Отримати список платежів"""
    service = PaymentService(db)
    return await service.get_payments(
        skip=skip, limit=limit, rental_id=rental_id, sale_id=sale_id,
        payment_type=payment_type, status=status, amount_from=amount_from,
        amount_to=amount_to, payment_date_from=payment_date_from,
        payment_date_to=payment_date_to
    )

@router.get("/{payment_id}", response_model=PaymentResponse)
async def get_payment(
    payment_id: int,
    db: Session = Depends(get_db)
):
    """Отримати платіж по ID"""
    service = PaymentService(db)
    payment = await service.get_payment(payment_id)
    if not payment:
        raise HTTPException(status_code=404, detail="Платіж не знайдено")
    return payment

@router.put("/{payment_id}", response_model=PaymentResponse)
async def update_payment(
    payment_id: int,
    payment_data: PaymentUpdate,
    db: Session = Depends(get_db)
):
    """Оновити платіж"""
    service = PaymentService(db)
    payment = await service.update_payment(payment_id, payment_data)
    if not payment:
        raise HTTPException(status_code=404, detail="Платіж не знайдено")
    return payment

@router.patch("/{payment_id}/status")
async def update_payment_status(
    payment_id: int,
    status: str,
    db: Session = Depends(get_db)
):
    """Змінити статус платежу"""
    service = PaymentService(db)
    payment = await service.update_status(payment_id, status)
    if not payment:
        raise HTTPException(status_code=404, detail="Платіж не знайдено")
    return payment