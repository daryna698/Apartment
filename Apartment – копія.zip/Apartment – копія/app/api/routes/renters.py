from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.schemas.renter import RenterCreate, RenterUpdate, RenterResponse
from app.services.renter import RenterService

router = APIRouter(prefix="/renters", tags=["Орендарі"])

@router.post("/", response_model=RenterResponse, status_code=201)
async def create_renter(
    renter_data: RenterCreate,
    db: Session = Depends(get_db)
):
    """Створити нового орендаря"""
    service = RenterService(db)
    return await service.create_renter(renter_data)

@router.get("/", response_model=List[RenterResponse])
async def get_renters(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    search: Optional[str] = Query(None, description="Пошук по імені/email/телефону"),
    is_active: Optional[bool] = Query(None, description="Фільтр по активності"),
    has_rental: Optional[bool] = Query(None, description="Чи має активну оренду"),
    db: Session = Depends(get_db)
):
    """Отримати список орендарів"""
    service = RenterService(db)
    return await service.get_renters(
        skip=skip, limit=limit, search=search,
        is_active=is_active, has_rental=has_rental
    )

@router.get("/{renter_id}", response_model=RenterResponse)
async def get_renter(
    renter_id: int,
    db: Session = Depends(get_db)
):
    """Отримати орендаря по ID"""
    service = RenterService(db)
    renter = await service.get_renter(renter_id)
    if not renter:
        raise HTTPException(status_code=404, detail="Орендаря не знайдено")
    return renter

@router.put("/{renter_id}", response_model=RenterResponse)
async def update_renter(
    renter_id: int,
    renter_data: RenterUpdate,
    db: Session = Depends(get_db)
):
    """Оновити дані орендаря"""
    service = RenterService(db)
    renter = await service.update_renter(renter_id, renter_data)
    if not renter:
        raise HTTPException(status_code=404, detail="Орендаря не знайдено")
    return renter

@router.delete("/{renter_id}")
async def delete_renter(
    renter_id: int,
    db: Session = Depends(get_db)
):
    """Видалити орендаря"""
    service = RenterService(db)
    success = await service.delete_renter(renter_id)
    if not success:
        raise HTTPException(status_code=404, detail="Орендаря не знайдено")
    return {"message": "Орендаря успішно видалено"}

@router.get("/{renter_id}/rentals")
async def get_renter_rentals(
    renter_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Отримати оренди орендаря"""
    service = RenterService(db)
    return await service.get_renter_rentals(renter_id, skip, limit)