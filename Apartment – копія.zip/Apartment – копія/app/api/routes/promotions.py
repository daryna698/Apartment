from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date
from app.core.database import get_db
from app.schemas.promotion import PromotionCreate, PromotionUpdate, PromotionResponse
from app.services.promotion import PromotionService

router = APIRouter(prefix="/promotions", tags=["Акції"])

@router.post("/", response_model=PromotionResponse, status_code=201)
async def create_promotion(
    promotion_data: PromotionCreate,
    db: Session = Depends(get_db)
):
    """Створити нову акцію"""
    service = PromotionService(db)
    return await service.create_promotion(promotion_data)

@router.get("/", response_model=List[PromotionResponse])
async def get_promotions(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    is_active: Optional[bool] = Query(None, description="Активні акції"),
    promotion_type: Optional[str] = Query(None, description="Тип акції"),
    start_date_from: Optional[date] = Query(None, description="Початок від"),
    start_date_to: Optional[date] = Query(None, description="Початок до"),
    search: Optional[str] = Query(None, description="Пошук по назві/опису"),
    db: Session = Depends(get_db)
):
    """Отримати список акцій"""
    service = PromotionService(db)
    return await service.get_promotions(
        skip=skip, limit=limit, is_active=is_active,
        promotion_type=promotion_type, start_date_from=start_date_from,
        start_date_to=start_date_to, search=search
    )

@router.get("/{promotion_id}", response_model=PromotionResponse)
async def get_promotion(
    promotion_id: int,
    db: Session = Depends(get_db)
):
    """Отримати акцію по ID"""
    service = PromotionService(db)
    promotion = await service.get_promotion(promotion_id)
    if not promotion:
        raise HTTPException(status_code=404, detail="Акцію не знайдено")
    return promotion

@router.put("/{promotion_id}", response_model=PromotionResponse)
async def update_promotion(
    promotion_id: int,
    promotion_data: PromotionUpdate,
    db: Session = Depends(get_db)
):
    """Оновити акцію"""
    service = PromotionService(db)
    promotion = await service.update_promotion(promotion_id, promotion_data)
    if not promotion:
        raise HTTPException(status_code=404, detail="Акцію не знайдено")
    return promotion

@router.delete("/{promotion_id}")
async def delete_promotion(
    promotion_id: int,
    db: Session = Depends(get_db)
):
    """Видалити акцію"""
    service = PromotionService(db)
    success = await service.delete_promotion(promotion_id)
    if not success:
        raise HTTPException(status_code=404, detail="Акцію не знайдено")
    return {"message": "Акцію успішно видалено"}