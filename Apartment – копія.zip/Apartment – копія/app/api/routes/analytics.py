from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import date
from app.core.database import get_db
from app.services.analytics import AnalyticsService

router = APIRouter(prefix="/analytics", tags=["Аналітика"])

@router.get("/dashboard")
async def get_dashboard_stats(
    date_from: Optional[date] = Query(None, description="Дата від"),
    date_to: Optional[date] = Query(None, description="Дата до"),
    db: Session = Depends(get_db)
):
    """Отримати статистику для дашборду"""
    service = AnalyticsService(db)
    return await service.get_dashboard_stats(date_from, date_to)

@router.get("/revenue")
async def get_revenue_stats(
    period: str = Query("month", description="Період: day, week, month, year"),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    db: Session = Depends(get_db)
):
    """Статистика доходів"""
    service = AnalyticsService(db)
    return await service.get_revenue_stats(period, date_from, date_to)

@router.get("/apartments")
async def get_apartments_stats(
    period: str = Query("month", description="Період: day, week, month, year"),
    city: Optional[str] = Query(None, description="Місто"),
    district: Optional[str] = Query(None, description="Район"),
    db: Session = Depends(get_db)
):
    """Статистика по квартирах"""
    service = AnalyticsService(db)
    return await service.get_apartments_stats(period, city, district)

@router.get("/popular-locations")
async def get_popular_locations(
    limit: int = Query(10, ge=1, le=100),
    period_days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Топ популярних локацій"""
    service = AnalyticsService(db)
    return await service.get_popular_locations(limit, period_days)

@router.get("/market-trends")
async def get_market_trends(
    period: str = Query("month", description="Період: week, month, quarter, year"),
    db: Session = Depends(get_db)
):
    """Тренди ринку нерухомості"""
    service = AnalyticsService(db)
    return await service.get_market_trends(period)
