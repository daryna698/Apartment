from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.schemas.building import BuildingCreate, BuildingUpdate, BuildingResponse
from app.services.building import BuildingService

router = APIRouter(prefix="/buildings", tags=["Будівлі"])

@router.post("/", response_model=BuildingResponse, status_code=201)
async def create_building(
    building_data: BuildingCreate,
    db: Session = Depends(get_db)
):
    """Створити нову будівлю"""
    service = BuildingService(db)
    return await service.create_building(building_data)

@router.get("/", response_model=List[BuildingResponse])
async def get_buildings(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    city: Optional[str] = Query(None, description="Фільтр по місту"),
    district: Optional[str] = Query(None, description="Фільтр по району"),
    has_elevator: Optional[bool] = Query(None, description="Наявність ліфта"),
    has_parking: Optional[bool] = Query(None, description="Наявність паркінгу"),
    search: Optional[str] = Query(None, description="Пошук по назві/адресі"),
    db: Session = Depends(get_db)
):
    """Отримати список будівель"""
    service = BuildingService(db)
    return await service.get_buildings(
        skip=skip, limit=limit, city=city, district=district,
        has_elevator=has_elevator, has_parking=has_parking, search=search
    )

@router.get("/{building_id}", response_model=BuildingResponse)
async def get_building(
    building_id: int,
    db: Session = Depends(get_db)
):
    """Отримати будівлю по ID"""
    service = BuildingService(db)
    building = await service.get_building(building_id)
    if not building:
        raise HTTPException(status_code=404, detail="Будівлю не знайдено")
    return building

@router.put("/{building_id}", response_model=BuildingResponse)
async def update_building(
    building_id: int,
    building_data: BuildingUpdate,
    db: Session = Depends(get_db)
):
    """Оновити будівлю"""
    service = BuildingService(db)
    building = await service.update_building(building_id, building_data)
    if not building:
        raise HTTPException(status_code=404, detail="Будівлю не знайдено")
    return building

@router.delete("/{building_id}")
async def delete_building(
    building_id: int,
    db: Session = Depends(get_db)
):
    """Видалити будівлю"""
    service = BuildingService(db)
    success = await service.delete_building(building_id)
    if not success:
        raise HTTPException(status_code=404, detail="Будівлю не знайдено")
    return {"message": "Будівлю успішно видалено"}

@router.get("/{building_id}/apartments")
async def get_building_apartments(
    building_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Отримати квартири в будівлі"""
    service = BuildingService(db)
    return await service.get_building_apartments(building_id, skip, limit)
