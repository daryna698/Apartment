from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from decimal import Decimal
from app.core.database import get_db
from app.schemas.apartment import ApartmentCreate, ApartmentUpdate, ApartmentResponse
from app.services.apartment import ApartmentService

router = APIRouter(prefix="/apartments", tags=["Квартири"])

@router.post("/", response_model=ApartmentResponse, status_code=201)
async def create_apartment(
    apartment_data: ApartmentCreate,
    db: Session = Depends(get_db)
):
    """Створити нову квартиру"""
    service = ApartmentService(db)
    return await service.create_apartment(apartment_data)

@router.get("/", response_model=List[ApartmentResponse])
async def get_apartments(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    building_id: Optional[int] = Query(None, description="ID будівлі"),
    apartment_type_id: Optional[int] = Query(None, description="ID типу квартири"),
    owner_id: Optional[int] = Query(None, description="ID власника"),
    city: Optional[str] = Query(None, description="Місто"),
    district: Optional[str] = Query(None, description="Район"),
    rooms_min: Optional[int] = Query(None, description="Мінімальна кількість кімнат"),
    rooms_max: Optional[int] = Query(None, description="Максимальна кількість кімнат"),
    area_min: Optional[Decimal] = Query(None, description="Мінімальна площа"),
    area_max: Optional[Decimal] = Query(None, description="Максимальна площа"),
    price_min: Optional[Decimal] = Query(None, description="Мінімальна ціна"),
    price_max: Optional[Decimal] = Query(None, description="Максимальна ціна"),
    rent_price_min: Optional[Decimal] = Query(None, description="Мінімальна ціна оренди"),
    rent_price_max: Optional[Decimal] = Query(None, description="Максимальна ціна оренди"),
    status: Optional[str] = Query(None, description="Статус квартири"),
    is_available_for_rent: Optional[bool] = Query(None, description="Доступна для оренди"),
    is_available_for_sale: Optional[bool] = Query(None, description="Доступна для продажу"),
    has_balcony: Optional[bool] = Query(None, description="Наявність балкону"),
    has_parking: Optional[bool] = Query(None, description="Наявність паркінгу"),
    search: Optional[str] = Query(None, description="Пошук по опису"),
    db: Session = Depends(get_db)
):
    """Отримати список квартир з фільтрацією"""
    service = ApartmentService(db)
    return await service.get_apartments(
        skip=skip, limit=limit, building_id=building_id,
        apartment_type_id=apartment_type_id, owner_id=owner_id,
        city=city, district=district, rooms_min=rooms_min, rooms_max=rooms_max,
        area_min=area_min, area_max=area_max, price_min=price_min, price_max=price_max,
        rent_price_min=rent_price_min, rent_price_max=rent_price_max,
        status=status, is_available_for_rent=is_available_for_rent,
        is_available_for_sale=is_available_for_sale, has_balcony=has_balcony,
        has_parking=has_parking, search=search
    )

@router.get("/{apartment_id}", response_model=ApartmentResponse)
async def get_apartment(
    apartment_id: int,
    db: Session = Depends(get_db)
):
    """Отримати квартиру по ID"""
    service = ApartmentService(db)
    apartment = await service.get_apartment(apartment_id)
    if not apartment:
        raise HTTPException(status_code=404, detail="Квартиру не знайдено")
    return apartment

@router.put("/{apartment_id}", response_model=ApartmentResponse)
async def update_apartment(
    apartment_id: int,
    apartment_data: ApartmentUpdate,
    db: Session = Depends(get_db)
):
    """Оновити квартиру"""
    service = ApartmentService(db)
    apartment = await service.update_apartment(apartment_id, apartment_data)
    if not apartment:
        raise HTTPException(status_code=404, detail="Квартиру не знайдено")
    return apartment

@router.delete("/{apartment_id}")
async def delete_apartment(
    apartment_id: int,
    db: Session = Depends(get_db)
):
    """Видалити квартиру"""
    service = ApartmentService(db)
    success = await service.delete_apartment(apartment_id)
    if not success:
        raise HTTPException(status_code=404, detail="Квартиру не знайдено")
    return {"message": "Квартиру успішно видалено"}

@router.get("/{apartment_id}/rentals")
async def get_apartment_rentals(
    apartment_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Отримати історію оренди квартири"""
    service = ApartmentService(db)
    return await service.get_apartment_rentals(apartment_id, skip, limit)

@router.get("/{apartment_id}/sales")
async def get_apartment_sales(
    apartment_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Отримати історію продажів квартири"""
    service = ApartmentService(db)
    return await service.get_apartment_sales(apartment_id, skip, limit)