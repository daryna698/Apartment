from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.schemas.owner import OwnerCreate, OwnerUpdate, OwnerResponse
from app.services.owner import OwnerService

router = APIRouter(prefix="/owners", tags=["Власники"])

@router.post("/", response_model=OwnerResponse, status_code=201)
async def create_owner(
    owner_data: OwnerCreate,
    db: Session = Depends(get_db)
):
    """Створити нового власника"""
    service = OwnerService(db)
    return await service.create_owner(owner_data)

@router.get("/", response_model=List[OwnerResponse])
async def get_owners(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    search: Optional[str] = Query(None, description="Пошук по імені/email/телефону"),
    city: Optional[str] = Query(None, description="Фільтр по місту"),
    is_active: Optional[bool] = Query(None, description="Фільтр по активності"),
    db: Session = Depends(get_db)
):
    """Отримати список власників"""
    service = OwnerService(db)
    return await service.get_owners(
        skip=skip, limit=limit, search=search, city=city, is_active=is_active
    )

@router.get("/{owner_id}", response_model=OwnerResponse)
async def get_owner(
    owner_id: int,
    db: Session = Depends(get_db)
):
    """Отримати власника по ID"""
    service = OwnerService(db)
    owner = await service.get_owner(owner_id)
    if not owner:
        raise HTTPException(status_code=404, detail="Власника не знайдено")
    return owner

@router.put("/{owner_id}", response_model=OwnerResponse)
async def update_owner(
    owner_id: int,
    owner_data: OwnerUpdate,
    db: Session = Depends(get_db)
):
    """Оновити дані власника"""
    service = OwnerService(db)
    owner = await service.update_owner(owner_id, owner_data)
    if not owner:
        raise HTTPException(status_code=404, detail="Власника не знайдено")
    return owner

@router.delete("/{owner_id}")
async def delete_owner(
    owner_id: int,
    db: Session = Depends(get_db)
):
    """Видалити власника"""
    service = OwnerService(db)
    success = await service.delete_owner(owner_id)
    if not success:
        raise HTTPException(status_code=404, detail="Власника не знайдено")
    return {"message": "Власника успішно видалено"}

@router.get("/{owner_id}/apartments")
async def get_owner_apartments(
    owner_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Отримати квартири власника"""
    service = OwnerService(db)
    return await service.get_owner_apartments(owner_id, skip, limit)
