from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date
from decimal import Decimal
from app.core.database import get_db
from app.schemas.sale import SaleCreate, SaleUpdate, SaleResponse
from app.services.sale import SaleService

router = APIRouter(prefix="/sales", tags=["Продажі"])

@router.post("/", response_model=SaleResponse, status_code=201)
async def create_sale(
    sale_data: SaleCreate,
    db: Session = Depends(get_db)
):
    """Створити нову угоду продажу"""
    service = SaleService(db)
    return await service.create_sale(sale_data)

@router.get("/", response_model=List[SaleResponse])
async def get_sales(
        skip: int = Query(0, ge=0),
        limit: int = Query(100, ge=1, le=1000),
        apartment_id: Optional[int] = Query(None, description="ID квартири"),
        seller_id: Optional[int] = Query(None, description="ID продавця"),
        buyer_id: Optional[int] = Query(None, description="ID покупця"),
        status: Optional[str] = Query(None, description="Статус угоди"),
        price_from: Optional[Decimal] = Query(None, description="Ціна від"),
        price_to: Optional[Decimal] = Query(None, description="Ціна до"),
        sale_date_from: Optional[date] = Query(None, description="Дата продажу від"),
        sale_date_to: Optional[date] = Query(None, description="Дата продажу до"),
        db: Session = Depends(get_db)
):
    """Отримати список угод продажу"""
    service = SaleService(db)
    return await service.get_sales(
        skip=skip, limit=limit, apartment_id=apartment_id,
        seller_id=seller_id, buyer_id=buyer_id, status=status,
        price_from=price_from, price_to=price_to,
        sale_date_from=sale_date_from, sale_date_to=sale_date_to
    )


@router.get("/{sale_id}", response_model=SaleResponse)
async def get_sale(
        sale_id: int,
        db: Session = Depends(get_db)
):
    """Отримати угоду продажу по ID"""
    service = SaleService(db)
    sale = await service.get_sale(sale_id)
    if not sale:
        raise HTTPException(status_code=404, detail="Угоду продажу не знайдено")
    return sale


@router.put("/{sale_id}", response_model=SaleResponse)
async def update_sale(
        sale_id: int,
        sale_data: SaleUpdate,
        db: Session = Depends(get_db)
):
    """Оновити угоду продажу"""
    service = SaleService(db)
    sale = await service.update_sale(sale_id, sale_data)
    if not sale:
        raise HTTPException(status_code=404, detail="Угоду продажу не знайдено")
    return sale


@router.delete("/{sale_id}")
async def delete_sale(
        sale_id: int,
        db: Session = Depends(get_db)
):
    """Видалити угоду продажу"""
    service = SaleService(db)
    success = await service.delete_sale(sale_id)
    if not success:
        raise HTTPException(status_code=404, detail="Угоду продажу не знайдено")
    return {"message": "Угоду продажу успішно видалено"}


@router.patch("/{sale_id}/status")
async def update_sale_status(
        sale_id: int,
        status: str,
        db: Session = Depends(get_db)
):
    """Змінити статус угоди продажу"""
    service = SaleService(db)
    sale = await service.update_status(sale_id, status)
    if not sale:
        raise HTTPException(status_code=404, detail="Угоду продажу не знайдено")
    return sale
