from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.schemas.review import ReviewCreate, ReviewUpdate, ReviewResponse
from app.services.review import ReviewService

router = APIRouter(prefix="/reviews", tags=["Відгуки"])

@router.post("/", response_model=ReviewResponse, status_code=201)
async def create_review(
    review_data: ReviewCreate,
    db: Session = Depends(get_db)
):
    """Створити новий відгук"""
    service = ReviewService(db)
    return await service.create_review(review_data)

@router.get("/", response_model=List[ReviewResponse])
async def get_reviews(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    apartment_id: Optional[int] = Query(None, description="ID квартири"),
    reviewer_id: Optional[int] = Query(None, description="ID рецензента"),
    rating_min: Optional[int] = Query(None, ge=1, le=5, description="Мінімальна оцінка"),
    rating_max: Optional[int] = Query(None, ge=1, le=5, description="Максимальна оцінка"),
    is_approved: Optional[bool] = Query(None, description="Схвалені відгуки"),
    search: Optional[str] = Query(None, description="Пошук по тексту"),
    db: Session = Depends(get_db)
):
    """Отримати список відгуків"""
    service = ReviewService(db)
    return await service.get_reviews(
        skip=skip, limit=limit, apartment_id=apartment_id,
        reviewer_id=reviewer_id, rating_min=rating_min, rating_max=rating_max,
        is_approved=is_approved, search=search
    )

@router.get("/{review_id}", response_model=ReviewResponse)
async def get_review(
    review_id: int,
    db: Session = Depends(get_db)
):
    """Отримати відгук по ID"""
    service = ReviewService(db)
    review = await service.get_review(review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Відгук не знайдено")
    return review

@router.put("/{review_id}", response_model=ReviewResponse)
async def update_review(
    review_id: int,
    review_data: ReviewUpdate,
    db: Session = Depends(get_db)
):
    """Оновити відгук"""
    service = ReviewService(db)
    review = await service.update_review(review_id, review_data)
    if not review:
        raise HTTPException(status_code=404, detail="Відгук не знайдено")
    return review

@router.delete("/{review_id}")
async def delete_review(
    review_id: int,
    db: Session = Depends(get_db)
):
    """Видалити відгук"""
    service = ReviewService(db)
    success = await service.delete_review(review_id)
    if not success:
        raise HTTPException(status_code=404, detail="Відгук не знайдено")
    return {"message": "Відгук успішно видалено"}

@router.patch("/{review_id}/approve")
async def approve_review(
    review_id: int,
    db: Session = Depends(get_db)
):
    """Схвалити відгук"""
    service = ReviewService(db)
    review = await service.approve_review(review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Відгук не знайдено")
    return review

@router.patch("/{review_id}/reject")
async def reject_review(
    review_id: int,
    db: Session = Depends(get_db)
):
    """Відхилити відгук"""
    service = ReviewService(db)
    review = await service.reject_review(review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Відгук не знайдено")
    return review
