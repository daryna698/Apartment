from fastapi import APIRouter
from app.api.routes.apartments import router as apartments_router
from .apartment_types import router as apartment_types_router
from .buildings import router as buildings_router
from .owners import router as owners_router
from .renters import router as renters_router
from .rentals import router as rentals_router
from .sales import router as sales_router
from .discounts import router as discounts_router
from .promotions import router as promotions_router
from .payments import router as payments_router
from .reviews import router as reviews_router
from .support import router as support_router
from .analytics import router as analytics_router

# Основний роутер для API
api_routes_router = APIRouter(prefix="routes")

# Додавання всіх роутерів
api_routes_router.include_router(apartments_router)
api_routes_router.include_router(apartment_types_router)
api_routes_router.include_router(buildings_router)
api_routes_router.include_router(owners_router)
api_routes_router.include_router(renters_router)
api_routes_router.include_router(rentals_router)
api_routes_router.include_router(sales_router)
api_routes_router.include_router(discounts_router)
api_routes_router.include_router(promotions_router)
api_routes_router.include_router(payments_router)
api_routes_router.include_router(reviews_router)
api_routes_router.include_router(support_router)
api_routes_router.include_router(analytics_router)
