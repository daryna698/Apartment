from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.schemas.support_ticket import SupportTicketCreate, SupportTicketUpdate, SupportTicketResponse
from app.services.support import SupportService

router = APIRouter(prefix="/support", tags=["Підтримка"])

@router.post("/", response_model=SupportTicketResponse, status_code=201)
async def create_support_ticket(
    ticket_data: SupportTicketCreate,
    db: Session = Depends(get_db)
):
    """Створити новий тікет підтримки"""
    service = SupportService(db)
    return await service.create_ticket(ticket_data)

@router.get("/", response_model=List[SupportTicketResponse])
async def get_support_tickets(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    status: Optional[str] = Query(None, description="Статус тікету"),
    priority: Optional[str] = Query(None, description="Пріоритет"),
    category: Optional[str] = Query(None, description="Категорія"),
    user_id: Optional[int] = Query(None, description="ID користувача"),
    search: Optional[str] = Query(None, description="Пошук по темі/опису"),
    db: Session = Depends(get_db)
):
    """Отримати список тікетів підтримки"""
    service = SupportService(db)
    return await service.get_tickets(
        skip=skip, limit=limit, status=status, priority=priority,
        category=category, user_id=user_id, search=search
    )

@router.get("/{ticket_id}", response_model=SupportTicketResponse)
async def get_support_ticket(
    ticket_id: int,
    db: Session = Depends(get_db)
):
    """Отримати тікет підтримки по ID"""
    service = SupportService(db)
    ticket = await service.get_ticket(ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Тікет не знайдено")
    return ticket

@router.put("/{ticket_id}", response_model=SupportTicketResponse)
async def update_support_ticket(
    ticket_id: int,
    ticket_data: SupportTicketUpdate,
    db: Session = Depends(get_db)
):
    """Оновити тікет підтримки"""
    service = SupportService(db)
    ticket = await service.update_ticket(ticket_id, ticket_data)
    if not ticket:
        raise HTTPException(status_code=404, detail="Тікет не знайдено")
    return ticket

@router.patch("/{ticket_id}/status")
async def update_ticket_status(
    ticket_id: int,
    status: str,
    db: Session = Depends(get_db)
):
    """Змінити статус тікету"""
    service = SupportService(db)
    ticket = await service.update_status(ticket_id, status)
    if not ticket:
        raise HTTPException(status_code=404, detail="Тікет не знайдено")
    return ticket

@router.patch("/{ticket_id}/assign")
async def assign_ticket(
    ticket_id: int,
    assignee_id: int,
    db: Session = Depends(get_db)
):
    """Призначити тікет співробітнику"""
    service = SupportService(db)
    ticket = await service.assign_ticket(ticket_id, assignee_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Тікет не знайдено")
    return ticket
