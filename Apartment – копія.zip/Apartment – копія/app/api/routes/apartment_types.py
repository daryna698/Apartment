from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.schemas.apartment_type import (
    ApartmentTypeCreate, ApartmentTypeUpdate, ApartmentTypeResponse
)
from app.services.apartment_type import ApartmentTypeService

router = APIRouter(prefix="/apartment-types", tags=["Типи квартир"])

@router.post("/", response_model=ApartmentTypeResponse, status_code=201)
async def create_apartment_type(
    apartment_type_data: ApartmentTypeCreate,
    db: Session = Depends(get_db)
):
    """Створити новий тип квартири"""
    service = ApartmentTypeService(db)
    return await service.create_apartment_type(apartment_type_data)

@router.get("/", response_model=List[ApartmentTypeResponse])
async def get_apartment_types(
    skip: int = Query(0, ge=0, description="Кількість записів для пропуску"),
    limit: int = Query(100, ge=1, le=1000, description="Ліміт записів"),
    is_active: Optional[bool] = Query(None, description="Фільтр по активності"),
    search: Optional[str] = Query(None, description="Пошук по назві"),
    db: Session = Depends(get_db)
):
    """Отримати список типів квартир"""
    service = ApartmentTypeService(db)
    return await service.get_apartment_types(
        skip=skip, limit=limit, is_active=is_active, search=search
    )

@router.get("/{apartment_type_id}", response_model=ApartmentTypeResponse)
async def get_apartment_type(
    apartment_type_id: int,
    db: Session = Depends(get_db)
):
    """Отримати тип квартири по ID"""
    service = ApartmentTypeService(db)
    apartment_type = await service.get_apartment_type(apartment_type_id)
    if not apartment_type:
        raise HTTPException(status_code=404, detail="Тип квартири не знайдено")
    return apartment_type

@router.put("/{apartment_type_id}", response_model=ApartmentTypeResponse)
async def update_apartment_type(
    apartment_type_id: int,
    apartment_type_data: ApartmentTypeUpdate,
    db: Session = Depends(get_db)
):
    """Оновити тип квартири"""
    service = ApartmentTypeService(db)
    apartment_type = await service.update_apartment_type(apartment_type_id, apartment_type_data)
    if not apartment_type:
        raise HTTPException(status_code=404, detail="Тип квартири не знайдено")
    return apartment_type

@router.delete("/{apartment_type_id}")
async def delete_apartment_type(
    apartment_type_id: int,
    db: Session = Depends(get_db)
):
    """Видалити тип квартири"""
    service = ApartmentTypeService(db)
    success = await service.delete_apartment_type(apartment_type_id)
    if not success:
        raise HTTPException(status_code=404, detail="Тип квартири не знайдено")
    return {"message": "Тип квартири успішно видалено"}