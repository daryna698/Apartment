from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date
from app.core.database import get_db
from app.schemas.rental import RentalCreate, RentalUpdate, RentalResponse
from app.services.rental import RentalService

router = APIRouter(prefix="/rentals", tags=["Оренда"])

@router.post("/", response_model=RentalResponse, status_code=201)
async def create_rental(
    rental_data: RentalCreate,
    db: Session = Depends(get_db)
):
    """Створити нову оренду"""
    service = RentalService(db)
    return await service.create_rental(rental_data)

@router.get("/", response_model=List[RentalResponse])
async def get_rentals(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    apartment_id: Optional[int] = Query(None, description="ID квартири"),
    renter_id: Optional[int] = Query(None, description="ID орендаря"),
    status: Optional[str] = Query(None, description="Статус оренди"),
    start_date_from: Optional[date] = Query(None, description="Початок оренди від"),
    start_date_to: Optional[date] = Query(None, description="Початок оренди до"),
    is_active: Optional[bool] = Query(None, description="Активна оренда"),
    db: Session = Depends(get_db)
):
    """Отримати список орендних угод"""
    service = RentalService(db)
    return await service.get_rentals(
        skip=skip, limit=limit, apartment_id=apartment_id,
        renter_id=renter_id, status=status,
        start_date_from=start_date_from, start_date_to=start_date_to,
        is_active=is_active
    )

@router.get("/{rental_id}", response_model=RentalResponse)
async def get_rental(
    rental_id: int,
    db: Session = Depends(get_db)
):
    """Отримати орендну угоду по ID"""
    service = RentalService(db)
    rental = await service.get_rental(rental_id)
    if not rental:
        raise HTTPException(status_code=404, detail="Орендну угоду не знайдено")
    return rental

@router.put("/{rental_id}", response_model=RentalResponse)
async def update_rental(
    rental_id: int,
    rental_data: RentalUpdate,
    db: Session = Depends(get_db)
):
    """Оновити орендну угоду"""
    service = RentalService(db)
    rental = await service.update_rental(rental_id, rental_data)
    if not rental:
        raise HTTPException(status_code=404, detail="Орендну угоду не знайдено")
    return rental

@router.delete("/{rental_id}")
async def delete_rental(
    rental_id: int,
    db: Session = Depends(get_db)
):
    """Видалити орендну угоду"""
    service = RentalService(db)
    success = await service.delete_rental(rental_id)
    if not success:
        raise HTTPException(status_code=404, detail="Орендну угоду не знайдено")
    return {"message": "Орендну угоду успішно видалено"}

@router.patch("/{rental_id}/status")
async def update_rental_status(
    rental_id: int,
    status: str,
    db: Session = Depends(get_db)
):
    """Змінити статус оренди"""
    service = RentalService(db)
    rental = await service.update_status(rental_id, status)
    if not rental:
        raise HTTPException(status_code=404, detail="Орендну угоду не знайдено")
    return rental

@router.post("/{rental_id}/extend")
async def extend_rental(
    rental_id: int,
    new_end_date: date,
    db: Session = Depends(get_db)
):
    """Продовжити оренду"""
    service = RentalService(db)
    rental = await service.extend_rental(rental_id, new_end_date)
    if not rental:
        raise HTTPException(status_code=404, detail="Орендну угоду не знайдено")
    return rental