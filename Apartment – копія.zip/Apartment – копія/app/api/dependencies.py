from typing import Generator, Optional, Dict, Any
from fastapi import Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.repositories.apartment import ApartmentRepository
from app.repositories.apartment_type import ApartmentTypeRepository
from app.repositories.building import BuildingRepository
from app.repositories.owner import OwnerRepository
from app.repositories.renter import RenterRepository
from app.repositories.rental import RentalRepository
from app.repositories.sale import SaleRepository
from app.repositories.discount import DiscountRepository
from app.repositories.promotion import PromotionRepository
from app.repositories.payment import PaymentRepository
from app.repositories.review import ReviewRepository
from app.repositories.support_ticket import SupportTicketRepository

from app.services.apartment import ApartmentService
from app.services.rental import RentalService
from app.services.sale import SaleService
from app.services.analytics import AnalyticsService
from app.services.discount import DiscountService
from app.services.promotion import PromotionService
from app.services.payment import PaymentService
from app.services.support import SupportService


# ============================================================================
# БАЗОВІ ЗАЛЕЖНОСТІ
# ============================================================================

def get_current_db() -> Generator[Session, None, None]:
    """Отримання поточної сесії бази даних"""
    return get_db()


# ============================================================================
# REPOSITORY DEPENDENCIES
# ============================================================================

def get_apartment_repository(db: Session = Depends(get_current_db)) -> ApartmentRepository:
    """Залежність для ApartmentRepository"""
    return ApartmentRepository(db)


def get_apartment_type_repository(db: Session = Depends(get_current_db)) -> ApartmentTypeRepository:
    """Залежність для ApartmentTypeRepository"""
    return ApartmentTypeRepository(db)


def get_building_repository(db: Session = Depends(get_current_db)) -> BuildingRepository:
    """Залежність для BuildingRepository"""
    return BuildingRepository(db)


def get_owner_repository(db: Session = Depends(get_current_db)) -> OwnerRepository:
    """Залежність для OwnerRepository"""
    return OwnerRepository(db)


def get_renter_repository(db: Session = Depends(get_current_db)) -> RenterRepository:
    """Залежність для RenterRepository"""
    return RenterRepository(db)


def get_rental_repository(db: Session = Depends(get_current_db)) -> RentalRepository:
    """Залежність для RentalRepository"""
    return RentalRepository(db)


def get_sale_repository(db: Session = Depends(get_current_db)) -> SaleRepository:
    """Залежність для SaleRepository"""
    return SaleRepository(db)


def get_discount_repository(db: Session = Depends(get_current_db)) -> DiscountRepository:
    """Залежність для DiscountRepository"""
    return DiscountRepository(db)


def get_promotion_repository(db: Session = Depends(get_current_db)) -> PromotionRepository:
    """Залежність для PromotionRepository"""
    return PromotionRepository(db)