"""
API модуль для Real Estate API
Містить всі endpoint-и для роботи з нерухомістю
"""

from fastapi import APIRouter
from app.api.routes import (apartments,apartment_types,buildings,owners,renters,rentals,
sales,discounts,promotions,payments,reviews,support,analytics)

# Створюємо головний роутер для API
api_router = APIRouter()

# Підключаємо всі роутери з префіксами та тегами
api_router.include_router(
    apartments.router,
    prefix="/apartments",
    tags=["apartments"]
)

api_router.include_router(
    apartment_types.router,
    prefix="/apartment-types",
    tags=["apartment-types"]
)

api_router.include_router(
    buildings.router,
    prefix="/buildings",
    tags=["buildings"]
)

api_router.include_router(
    owners.router,
    prefix="/owners",
    tags=["owners"]
)

api_router.include_router(
    renters.router,
    prefix="/renters",
    tags=["renters"]
)

api_router.include_router(
    rentals.router,
    prefix="/rentals",
    tags=["rentals"]
)

api_router.include_router(
    sales.router,
    prefix="/sales",
    tags=["sales"]
)

api_router.include_router(
    discounts.router,
    prefix="/discounts",
    tags=["discounts"]
)

api_router.include_router(
    promotions.router,
    prefix="/promotions",
    tags=["promotions"]
)

api_router.include_router(
    payments.router,
    prefix="/payments",
    tags=["payments"]
)

api_router.include_router(
    reviews.router,
    prefix="/reviews",
    tags=["reviews"]
)

api_router.include_router(
    support.router,
    prefix="/support",
    tags=["support"]
)

api_router.include_router(
    analytics.router,
    prefix="/analytics",
    tags=["analytics"]
)