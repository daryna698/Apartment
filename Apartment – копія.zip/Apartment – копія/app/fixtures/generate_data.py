import random
from datetime import datetime, timedelta, date
from typing import List
from sqlalchemy.orm import Session

from app.core.database import SessionLocal, engine, Base
from app.models.apartment_type import ApartmentType
from app.models.building import Building
from app.models.owner import Owner
from app.models.renter import Renter
from app.models.apartment import Apartment, ApartmentStatus
from app.models.rental import Rental, RentalStatus
from app.models.sale import Sale, SaleStatus
from app.models.discount import Discount, DiscountType
from app.models.promotion import Promotion
from app.models.payment import Payment, PaymentType, PaymentStatus, PaymentMethod
from app.models.review import Review
from app.models.support_ticket import SupportTicket, TicketStatus, TicketPriority, TicketCategory

# Ініціалізація Faker з українською локалізацією
fake = Faker(['uk_UA', 'en_US'])


class DataGenerator:
    def __init__(self, db: Session):
        self.db = db

    def generate_apartment_types(self, count: int = 10) -> List[ApartmentType]:
        """Генерація типів квартир"""
        types_data = [
            ("Студія", "Квартира-студія з відкритим плануванням"),
            ("1-кімнатна", "Однокімнатна квартира"),
            ("2-кімнатна", "Двокімнатна квартира"),
            ("3-кімнатна", "Трикімнатна квартира"),
            ("4-кімнатна", "Чотирикімнатна квартира"),
            ("5-кімнатна", "П'ятикімнатна квартира"),
            ("Пентхаус", "Елітна квартира на верхньому поверсі"),
            ("Дуплекс", "Двоповерхова квартира"),
            ("Лофт", "Квартира в стилі лофт"),
            ("Апартаменти", "Апартаменти готельного типу"),
        ]

        apartment_types = []
        for i, (name, description) in enumerate(types_data[:count]):
            apartment_type = ApartmentType(
                name=name,
                description=description,
                is_active=random.choice([True, True, True, False])  # 75% активних
            )
            self.db.add(apartment_type)
            apartment_types.append(apartment_type)

        self.db.commit()
        return apartment_types

    def generate_buildings(self, count: int = 20) -> List[Building]:
        """Генерація будівель"""
        cities = ["Київ", "Харків", "Одеса", "Дніпро", "Львів", "Запоріжжя", "Кривий Ріг"]
        districts = ["Печерський", "Шевченківський", "Подільський", "Солом'янський", "Оболонський"]

        buildings = []
        for _ in range(count):
            city = random.choice(cities)
            building = Building(
                name=fake.company(),
                address=fake.address(),
                city=city,
                district=random.choice(districts) if random.random() > 0.3 else None,
                postal_code=fake.postcode() if random.random() > 0.5 else None,
                floors_count=random.randint(5, 25),
                year_built=random.randint(1970, 2024),
                elevator=random.choice([True, False]),
                parking=random.choice([True, False]),
                security=random.choice([True, False]),
                latitude=fake.latitude() if random.random() > 0.4 else None,
                longitude=fake.longitude() if random.random() > 0.4 else None,
                description=fake.text(max_nb_chars=200) if random.random() > 0.6 else None,
                is_active=random.choice([True, True, True, False])
            )
            self.db.add(building)
            buildings.append(building)

        self.db.commit()
        return buildings

    def generate_owners(self, count: int = 30) -> List[Owner]:
        """Генерація власників"""
        owners = []
        for _ in range(count):
            owner = Owner(
                first_name=fake.first_name(),
                last_name=fake.last_name(),
                middle_name=fake.middle_name() if random.random() > 0.4 else None,
                email=fake.unique.email(),
                phone=fake.phone_number(),
                alternative_phone=fake.phone_number() if random.random() > 0.6 else None,
                address=fake.address() if random.random() > 0.7 else None,
                city=fake.city() if random.random() > 0.7 else None,
                notes=fake.text(max_nb_chars=150) if random.random() > 0.8 else None,
                is_active=random.choice([True, True, True, False])
            )
            self.db.add(owner)
            owners.append(owner)

        self.db.commit()
        return owners

    def generate_renters(self, count: int = 50) -> List[Renter]:
        """Генерація орендарів"""
        renters = []
        workplaces = ["IT компанія", "Банк", "Медична клініка", "Університет", "Торгова мережа"]
        positions = ["Менеджер", "Розробник", "Аналітик", "Консультант", "Спеціаліст"]

        for _ in range(count):
            renter = Renter(
                first_name=fake.first_name(),
                last_name=fake.last_name(),
                middle_name=fake.middle_name() if random.random() > 0.4 else None,
                birth_date=fake.date_of_birth(minimum_age=18, maximum_age=65),
                email=fake.unique.email(),
                phone=fake.phone_number(),
                alternative_phone=fake.phone_number() if random.random() > 0.6 else None,
                current_address=fake.address() if random.random() > 0.5 else None,
                city=fake.city() if random.random() > 0.7 else None,
                workplace=random.choice(workplaces) if random.random() > 0.3 else None,
                position=random.choice(positions) if random.random() > 0.3 else None,
                monthly_income=random.randint(2000000, 15000000) if random.random() > 0.4 else None,  # в копійках
                notes=fake.text(max_nb_chars=150) if random.random() > 0.8 else None,
                is_active=random.choice([True, True, True, False])
            )
            self.db.add(renter)
            renters.append(renter)

        self.db.commit()
        return renters

    def generate_apartments(self, buildings: List[Building], owners: List[Owner],
                            apartment_types: List[ApartmentType], count: int = 100) -> List[Apartment]:
        """Генерація квартир"""
        apartments = []
        renovation_types = ["без ремонту", "косметичний", "євроремонт", "дизайнерський"]

        for _ in range(count):
            building = random.choice(buildings)
            apartment = Apartment(
                number=str(random.randint(1, 200)),
                floor=random.randint(1, building.floors_count or 10),
                room_count=random.randint(1, 5),
                total_area=round(random.uniform(25.0, 150.0), 1),
                living_area=round(random.uniform(15.0, 100.0), 1) if random.random() > 0.3 else None,
                kitchen_area=round(random.uniform(8.0, 25.0), 1) if random.random() > 0.4 else None,
                bathroom_count=random.randint(1, 3),
                balcony=random.choice([True, False]),
                loggia=random.choice([True, False]),
                separate_bathroom=random.choice([True, False]),
                renovation_type=random.choice(renovation_types),
                furnished=random.choice([True, False]),
                appliances=fake.text(max_nb_chars=100) if random.random() > 0.7 else None,
                rent_price=random.randint(800000, 5000000) if random.random() > 0.3 else None,  # в копійках
                sale_price=random.randint(5000000, 50000000) if random.random() > 0.5 else None,  # в копійках
                utilities_included=random.choice([True, False]),
                status=random.choice(list(ApartmentStatus)),
                description=fake.text(max_nb_chars=300) if random.random() > 0.5 else None,
                notes=fake.text(max_nb_chars=100) if random.random() > 0.8 else None,
                images=f'["{fake.image_url()}", "{fake.image_url()}"]' if random.random() > 0.6 else None,
                building_id=building.id,
                owner_id=random.choice(owners).id,
                apartment_type_id=random.choice(apartment_types).id
            )
            self.db.add(apartment)
            apartments.append(apartment)

        self.db.commit()
        return apartments

    def generate_discounts(self, count: int = 15) -> List[Discount]:
        """Генерація знижок"""
        discount_names = [
            "Знижка для студентів", "Довгострокова оренда", "Новорічна знижка",
            "Знижка для сімей", "Літня пропозиція", "Осіння знижка",
            "Знижка для постійних клієнтів", "Вікенд пропозиція"
        ]

        discounts = []
        for i in range(count):
            start_date = fake.date_time_between(start_date='-30d', end_date='+30d')
            end_date = start_date + timedelta(days=random.randint(30, 365))

            discount = Discount(
                name=random.choice(discount_names) + f" #{i}",
                description=fake.text(max_nb_chars=200),
                discount_type=random.choice(list(DiscountType)),
                value=random.randint(500, 2000) if random.choice([True, False]) else random.randint(100000, 1000000),
                start_date=start_date,
                end_date=end_date,
                max_uses=random.randint(10, 100) if random.random() > 0.3 else None,
                current_uses=random.randint(0, 20),
                min_rental_period=random.randint(3, 12) if random.random() > 0.5 else None,
                min_apartment_price=random.randint(1000000, 3000000) if random.random() > 0.6 else None,
                is_active=random.choice([True, True, False])
            )
            self.db.add(discount)
            discounts.append(discount)

        self.db.commit()
        return discounts

    def generate_promotions(self, discounts: List[Discount], count: int = 10) -> List[Promotion]:
        """Генерація акцій"""
        promo_titles = [
            "Весняна пропозиція", "Літні канікули", "Осінні знижки",
            "Зимова акція", "Студентська пропозиція", "Сімейна знижка"
        ]

        promotions = []
        for i in range(count):
            start_date = fake.date_time_between(start_date='-30d', end_date='+30d')
            end_date = start_date + timedelta(days=random.randint(30, 180))

            promotion = Promotion(
                title=random.choice(promo_titles) + f" {i + 1}",
                description=fake.text(max_nb_chars=400),
                start_date=start_date,
                end_date=end_date,
                target_apartment_type=random.choice(
                    ["1-кімнатна", "2-кімнатна", "студія"]) if random.random() > 0.6 else None,
                target_city=random.choice(["Київ", "Харків", "Львів"]) if random.random() > 0.7 else None,
                target_price_range_min=random.randint(500000, 1500000) if random.random() > 0.8 else None,
                target_price_range_max=random.randint(2000000, 5000000) if random.random() > 0.8 else None,
                is_active=random.choice([True, True, False]),
                discount_id=random.choice(discounts).id if random.random() > 0.3 else None
            )
            self.db.add(promotion)
            promotions.append(promotion)

        self.db.commit()
        return promotions

    def generate_rentals(self, apartments: List[Apartment], renters: List[Renter], count: int = 60) -> List[Rental]:
        """Генерація договорів оренди"""
        rentals = []

        # Фільтруємо квартири, доступні для оренди
        available_apartments = [apt for apt in apartments if
                                apt.rent_price and apt.status in [ApartmentStatus.AVAILABLE, ApartmentStatus.RENTED]]

        for _ in range(min(count, len(available_apartments))):
            apartment = random.choice(available_apartments)
            start_date = fake.date_time_between(start_date='-365d', end_date='+30d')
            rental_period = random.randint(3, 24)  # від 3 до 24 місяців
            end_date = start_date + timedelta(days=rental_period * 30)

            rental = Rental(
                start_date=start_date,
                end_date=end_date,
                monthly_rent=apartment.rent_price or random.randint(800000, 3000000),
                deposit=random.randint(800000, 2000000),
                utilities_cost=random.randint(200000, 800000),
                status=random.choice(list(RentalStatus)),
                contract_number=f"РД-{fake.random_int(min=1000, max=9999)}",
                contract_date=start_date + timedelta(days=random.randint(-5, 5)),
                pets_allowed=random.choice([True, False]),
                smoking_allowed=random.choice([True, False]),
                guests_allowed=random.choice([True, True, False]),  # частіше дозволено
                notes=fake.text(max_nb_chars=200) if random.random() > 0.7 else None,
                termination_reason=fake.text(max_nb_chars=100) if random.random() > 0.9 else None,
                apartment_id=apartment.id,
                renter_id=random.choice(renters).id
            )
            self.db.add(rental)
            rentals.append(rental)

            # Оновлюємо статус квартири
            if rental.status == RentalStatus.ACTIVE:
                apartment.status = ApartmentStatus.RENTED

        self.db.commit()
        return rentals

    def generate_sales(self, apartments: List[Apartment], owners: List[Owner],
                       renters: List[Renter], count: int = 20) -> List[Sale]:
        """Генерація продажів"""
        sales = []

        # Фільтруємо квартири, доступні для продажу
        available_apartments = [apt for apt in apartments if apt.sale_price]

        for _ in range(min(count, len(available_apartments))):
            apartment = random.choice(available_apartments)
            sale_date = fake.date_time_between(start_date='-180d', end_date='+30d')

            sale = Sale(
                sale_price=apartment.sale_price or random.randint(5000000, 30000000),
                sale_date=sale_date,
                contract_date=sale_date + timedelta(days=random.randint(1, 14)),
                status=random.choice(list(SaleStatus)),
                commission_rate=random.randint(200, 800),  # 2-8%
                commission_amount=0,  # буде розраховано автоматично
                notes=fake.text(max_nb_chars=200) if random.random() > 0.7 else None,
                cancellation_reason=fake.text(max_nb_chars=100) if random.random() > 0.95 else None,
                apartment_id=apartment.id,
                seller_id=apartment.owner_id,
                buyer_id=random.choice(renters).id
            )

            # Розрахунок комісії
            sale.commission_amount = (sale.sale_price * sale.commission_rate) // 10000

            self.db.add(sale)
            sales.append(sale)

            # Оновлюємо статус квартири
            if sale.status == SaleStatus.COMPLETED:
                apartment.status = ApartmentStatus.SOLD

        self.db.commit()
        return sales

    def generate_payments(self, rentals: List[Rental], count: int = 200) -> List[Payment]:
        """Генерація платежів"""
        payments = []

        for rental in rentals:
            # Генеруємо платежі для кожної оренди
            num_payments = random.randint(1, 12)  # до 12 місяців платежів

            for month in range(num_payments):
                due_date = rental.start_date + timedelta(days=30 * month)
                if due_date > datetime.now():
                    break

                payment = Payment(
                    amount=rental.monthly_rent,
                    payment_type=PaymentType.RENT,
                    payment_method=random.choice(list(PaymentMethod)),
                    due_date=due_date,
                    payment_date=due_date + timedelta(days=random.randint(-5, 10)),
                    status=random.choice(list(PaymentStatus)),
                    transaction_id=f"TXN-{fake.random_int(min=100000, max=999999)}",
                    reference_number=f"REF-{fake.random_int(min=1000, max=9999)}",
                    description=f"Оплата оренди за {due_date.strftime('%B %Y')}",
                    notes=fake.text(max_nb_chars=100) if random.random() > 0.8 else None,
                    rental_id=rental.id
                )
                self.db.add(payment)
                payments.append(payment)

                if len(payments) >= count:
                    break

            if len(payments) >= count:
                break

        self.db.commit()
        return payments

    def generate_reviews(self, apartments: List[Apartment], renters: List[Renter], count: int = 40) -> List[Review]:
        """Генерація відгуків"""
        reviews = []
        review_titles = [
            "Чудова квартира", "Рекомендую", "Гарне розташування",
            "Затишне житло", "Все сподобалось", "Хороший власник"
        ]

        for _ in range(count):
            review = Review(
                rating=random.randint(3, 5),  # переважно позитивні відгуки
                title=random.choice(review_titles) if random.random() > 0.3 else None,
                comment=fake.text(max_nb_chars=300) if random.random() > 0.2 else None,
                cleanliness_rating=random.randint(1, 5),
                location_rating=random.randint(1, 5),
                value_rating=random.randint(1, 5),
                communication_rating=random.randint(1, 5),
                owner_response=fake.text(max_nb_chars=200) if random.random() > 0.6 else None,
                response_date=fake.date_time_between(start_date='-30d',
                                                     end_date='now') if random.random() > 0.6 else None,
                apartment_id=random.choice(apartments).id,
                renter_id=random.choice(renters).id
            )
            self.db.add(review)
            reviews.append(review)

        self.db.commit()
        return reviews

    def generate_support_tickets(self, renters: List[Renter], count: int = 25) -> List[SupportTicket]:
        """Генерація тікетів підтримки"""
        tickets = []
        ticket_subjects = [
            "Проблема з оплатою", "Питання по договору", "Технічна проблема",
            "Скарга на квартиру", "Запит на обслуговування", "Загальне питання"
        ]

        for _ in range(count):
            created_date = fake.date_time_between(start_date='-90d', end_date='now')

            ticket = SupportTicket(
                subject=random.choice(ticket_subjects),
                description=fake.text(max_nb_chars=500),
                category=random.choice(list(TicketCategory)),
                priority=random.choice(list(TicketPriority)),
                status=random.choice(list(TicketStatus)),
                contact_email=fake.email() if random.random() > 0.3 else None,
                contact_phone=fake.phone_number() if random.random() > 0.5 else None,
                resolution=fake.text(max_nb_chars=300) if random.random() > 0.5 else None,
                resolved_at=created_date + timedelta(days=random.randint(1, 14)) if random.random() > 0.4 else None,
                resolved_by=fake.name() if random.random() > 0.5 else None,
                internal_notes=fake.text(max_nb_chars=200) if random.random() > 0.7 else None,
                is_urgent=random.choice([True, False]),
                renter_id=random.choice(renters).id if random.random() > 0.2 else None
            )
            self.db.add(ticket)
            tickets.append(ticket)

        self.db.commit()
        return tickets

    def generate_all_data(self):
        """Генерація всіх тестових даних"""
        print("Початок генерації тестових даних...")

        # Створення таблиць
        Base.metadata.create_all(bind=engine)

        # Генерація в правильному порядку (враховуючи залежності)
        print("Генерація типів квартир...")
        apartment_types = self.generate_apartment_types(10)

        print("Генерація будівель...")
        buildings = self.generate_buildings(20)

        print("Генерація власників...")
        owners = self.generate_owners(30)

        print("Генерація орендарів...")
        renters = self.generate_renters(50)

        print("Генерація квартир...")
        apartments = self.generate_apartments(buildings, owners, apartment_types, 100)

        print("Генерація знижок...")
        discounts = self.generate_discounts(15)

        print("Генерація акцій...")
        promotions = self.generate_promotions(discounts, 10)

        print("Генерація договорів оренди...")
        rentals = self.generate_rentals(apartments, renters, 60)

        print("Генерація продажів...")
        sales = self.generate_sales(apartments, owners, renters, 20)

        print("Генерація платежів...")
        payments = self.generate_payments(rentals, 200)

        print("Генерація відгуків...")
        reviews = self.generate_reviews(apartments, renters, 40)

        print("Генерація тікетів підтримки...")
        support_tickets = self.generate_support_tickets(renters, 25)

        print("Тестові дані успішно згенеровано!")

        # Статистика
        print(f"""
        Згенеровано:
        - Типи квартир: {len(apartment_types)}
        - Будівлі: {len(buildings)}
        - Власники: {len(owners)}
        - Орендарі: {len(renters)}
        - Квартири: {len(apartments)}
        - Знижки: {len(discounts)}
        - Акції: {len(promotions)}
        - Договори оренди: {len(rentals)}
        - Продажі: {len(sales)}
        - Платежі: {len(payments)}
        - Відгуки: {len(reviews)}
        - Тікети підтримки: {len(support_tickets)}
        """)


def main():
    """Основна функція для запуску генерації даних"""
    db = SessionLocal()
    try:
        generator = DataGenerator(db)
        generator.generate_all_data()
    finally:
        db.close()


if __name__ == "__main__":
    main()