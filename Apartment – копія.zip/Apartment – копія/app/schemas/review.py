from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime

class ReviewBase(BaseModel):
    rating: int = Field(..., ge=1, le=5, description="Оцінка від 1 до 5")
    title: Optional[str] = Field(None, max_length=200, description="Заголовок відгуку")
    comment: Optional[str] = Field(None, description="Коментар до відгуку")
    is_approved: bool = Field(default=False, description="Чи схвалено відгук модератором")
    apartment_id: int = Field(..., description="ID квартири")
    renter_id: int = Field(..., description="ID орендаря")

class ReviewCreate(ReviewBase):
    """Схема створення відгуку"""
    pass

class ReviewUpdate(BaseModel):
    """Схема оновлення відгуку"""
    rating: Optional[int] = Field(None, ge=1, le=5)
    title: Optional[str] = Field(None, max_length=200)
    comment: Optional[str] = None
    is_approved: Optional[bool] = None
    apartment_id: Optional[int] = None
    renter_id: Optional[int] = None

class ReviewInDB(ReviewBase):
    """Схема, яка містить базу + дані з бази"""
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class ReviewRead(ReviewInDB):
    """Схема читання відгуку (деталізація)"""
    pass

class ReviewResponse(ReviewRead):
    """Схема відповіді для API"""
    pass
