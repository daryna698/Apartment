from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional
from datetime import datetime
import re


class OwnerBase(BaseModel):
    first_name: str = Field(..., min_length=1, max_length=100, description="Ім'я")
    last_name: str = Field(..., min_length=1, max_length=100, description="Прізвище")
    middle_name: Optional[str] = Field(None, max_length=100, description="По батькові")

    email: EmailStr = Field(..., description="Email адреса")
    phone: str = Field(..., min_length=10, max_length=20, description="Номер телефону")
    alternative_phone: Optional[str] = Field(None, min_length=10, max_length=20, description="Альтернативний телефон")

    address: Optional[str] = Field(None, max_length=500, description="Адреса проживання")
    city: Optional[str] = Field(None, max_length=100, description="Місто")

    notes: Optional[str] = Field(None, description="Додаткові нотатки")
    is_active: bool = Field(True, description="Активний статус")


class SomeModel(BaseModel):
    phone: Optional[str]
    alternative_phone: Optional[str]

    @validator('phone', 'alternative_phone')
    def validate_phone(cls, v):
        if v is None:
            return v
        # Видаляємо пробіли та дефіси
        cleaned = v.replace(' ', '').replace('-', '')
        # Простий регекс для українських номерів телефону
        if not re.match(r'^(\+38)?0\d{9}$', cleaned):
            raise ValueError('Невірний формат номера телефону. Очікується: +380XXXXXXXXX або 0XXXXXXXXX')
        return v


class OwnerCreate(OwnerBase):
    pass


class OwnerUpdate(BaseModel):
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    middle_name: Optional[str] = Field(None, max_length=100)
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, min_length=10, max_length=20)
    alternative_phone: Optional[str] = Field(None, min_length=10, max_length=20)
    address: Optional[str] = Field(None, max_length=500)
    city: Optional[str] = Field(None, max_length=100)
    notes: Optional[str] = None
    is_active: Optional[bool] = None


class OwnerResponse(OwnerBase):
    id: int
    full_name: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
