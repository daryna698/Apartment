from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime
from enum import Enum


class DiscountTypeEnum(str, Enum):
    PERCENTAGE = "percentage"
    FIXED_AMOUNT = "fixed_amount"


class DiscountBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200, description="Назва знижки")
    description: Optional[str] = Field(None, description="Опис знижки")
    discount_type: DiscountTypeEnum = Field(..., description="Тип знижки")
    value: int = Field(..., gt=0, description="Значення знижки")

    start_date: datetime = Field(..., description="Дата початку дії")
    end_date: datetime = Field(..., description="Дата закінчення дії")

    max_uses: Optional[int] = Field(None, gt=0, description="Максимальна кількість використань")
    current_uses: int = Field(0, ge=0, description="Поточна кількість використань")

    min_rental_period: Optional[int] = Field(None, gt=0, description="Мінімальний період оренди")
    min_apartment_price: Optional[int] = Field(None, gt=0, description="Мінімальна ціна квартири")

    is_active: bool = Field(True, description="Активний статус")

    @validator('end_date')
    def validate_end_date(cls, v, values):
        if 'start_date' in values and v <= values['start_date']:
            raise ValueError('Дата закінчення повинна бути пізніше дати початку')
        return v

    @validator('value')
    def validate_value(cls, v, values):
        if 'discount_type' in values:
            if values['discount_type'] == DiscountTypeEnum.PERCENTAGE and v > 10000:  # 100% = 10000
                raise ValueError('Відсоток знижки не може перевищувати 100%')
        return v

    @validator('current_uses')
    def validate_current_uses(cls, v, values):
        if 'max_uses' in values and values['max_uses'] is not None and v > values['max_uses']:
            raise ValueError('Поточна кількість використань не може перевищувати максимальну')
        return v


class DiscountCreate(DiscountBase):
    current_uses: int = Field(0, ge=0)


class DiscountUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = None
    discount_type: Optional[DiscountTypeEnum] = None
    value: Optional[int] = Field(None, gt=0)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    max_uses: Optional[int] = Field(None, gt=0)
    current_uses: Optional[int] = Field(None, ge=0)
    min_rental_period: Optional[int] = Field(None, gt=0)
    min_apartment_price: Optional[int] = Field(None, gt=0)
    is_active: Optional[bool] = None


class DiscountResponse(DiscountBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
