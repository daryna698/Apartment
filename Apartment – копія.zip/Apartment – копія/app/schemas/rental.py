from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime
from enum import Enum


class RentalStatusEnum(str, Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    TERMINATED = "terminated"
    PENDING = "pending"


class RentalBase(BaseModel):
    start_date: datetime = Field(..., description="Дата початку оренди")
    end_date: datetime = Field(..., description="Дата закінчення оренди")
    monthly_rent: int = Field(..., gt=0, description="Місячна орендна плата в копійках")
    deposit: int = Field(0, ge=0, description="Застава в копійках")
    utilities_cost: int = Field(0, ge=0, description="Вартість комунальних в копійках")

    status: RentalStatusEnum = Field(RentalStatusEnum.PENDING, description="Статус оренди")

    contract_number: Optional[str] = Field(None, max_length=50, description="Номер договору")
    contract_date: Optional[datetime] = Field(None, description="Дата підписання договору")

    pets_allowed: bool = Field(False, description="Дозволені домашні тварини")
    smoking_allowed: bool = Field(False, description="Дозволене паління")
    guests_allowed: bool = Field(True, description="Дозволені гості")

    notes: Optional[str] = Field(None, description="Додаткові нотатки")
    termination_reason: Optional[str] = Field(None, description="Причина розірвання")

    apartment_id: int = Field(..., gt=0, description="ID квартири")
    renter_id: int = Field(..., gt=0, description="ID орендаря")

    @validator('end_date')
    def validate_end_date(cls, v, values):
        if 'start_date' in values and v <= values['start_date']:
            raise ValueError('Дата закінчення повинна бути пізніше дати початку')
        return v

    @validator('contract_date')
    def validate_contract_date(cls, v, values):
        if v is not None and 'start_date' in values and v > values['start_date']:
            raise ValueError('Дата договору не може бути пізніше дати початку оренди')
        return v


class RentalCreate(RentalBase):
    pass


class RentalUpdate(BaseModel):
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    monthly_rent: Optional[int] = Field(None, gt=0)
    deposit: Optional[int] = Field(None, ge=0)
    utilities_cost: Optional[int] = Field(None, ge=0)
    status: Optional[RentalStatusEnum] = None
    contract_number: Optional[str] = Field(None, max_length=50)
    contract_date: Optional[datetime] = None
    pets_allowed: Optional[bool] = None
    smoking_allowed: Optional[bool] = None
    guests_allowed: Optional[bool] = None
    notes: Optional[str] = None
    termination_reason: Optional[str] = None
    apartment_id: Optional[int] = Field(None, gt=0)
    renter_id: Optional[int] = Field(None, gt=0)


class RentalResponse(RentalBase):
    id: int
    total_monthly_cost: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    # Nested objects
    apartment: Optional['ApartmentResponse'] = None
    renter: Optional['RenterResponse'] = None

    class Config:
        from_attributes = True