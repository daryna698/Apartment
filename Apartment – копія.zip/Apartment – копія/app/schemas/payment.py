from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime, date
from decimal import Decimal


class PaymentBase(BaseModel):
    payment_date: date
    amount: Decimal = Field(..., gt=0)
    payment_type: str = Field("rent", max_length=50)
    payment_method: str = Field("transfer", max_length=50)
    status: str = Field("completed", max_length=50)
    description: Optional[str] = None
    rental_id: Optional[int] = None


class PaymentCreate(PaymentBase):
    pass


class PaymentUpdate(BaseModel):
    payment_date: Optional[date] = None
    amount: Optional[Decimal] = Field(None, gt=0)
    payment_type: Optional[str] = Field(None, max_length=50)
    payment_method: Optional[str] = Field(None, max_length=50)
    status: Optional[str] = Field(None, max_length=50)
    description: Optional[str] = None
    rental_id: Optional[int] = None


class PaymentInDB(PaymentBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime


class PaymentRead(PaymentInDB):
    pass


class PaymentResponse:
    pass