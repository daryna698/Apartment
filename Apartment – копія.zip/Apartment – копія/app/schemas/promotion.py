from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime


class PromotionBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=200, description="Заголовок акції")
    description: str = Field(..., min_length=1, description="Опис акції")

    start_date: datetime = Field(..., description="Дата початку акції")
    end_date: datetime = Field(..., description="Дата закінчення акції")

    target_apartment_type: Optional[str] = Field(None, max_length=100, description="Цільовий тип квартири")
    target_city: Optional[str] = Field(None, max_length=100, description="Цільове місто")
    target_price_range_min: Optional[int] = Field(None, gt=0, description="Мінімальна ціна")
    target_price_range_max: Optional[int] = Field(None, gt=0, description="Максимальна ціна")

    is_active: bool = Field(True, description="Активний статус")
    discount_id: Optional[int] = Field(None, gt=0, description="ID пов'язаної знижки")

    @validator('end_date')
    def validate_end_date(cls, v, values):
        if 'start_date' in values and v <= values['start_date']:
            raise ValueError('Дата закінчення повинна бути пізніше дати початку')
        return v

    @validator('target_price_range_max')
    def validate_price_range(cls, v, values):
        if v is not None and 'target_price_range_min' in values and values['target_price_range_min'] is not None:
            if v <= values['target_price_range_min']:
                raise ValueError('Максимальна ціна повинна бути більше мінімальної')
        return v


class PromotionCreate(PromotionBase):
    pass


class PromotionUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, min_length=1)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    target_apartment_type: Optional[str] = Field(None, max_length=100)
    target_city: Optional[str] = Field(None, max_length=100)
    target_price_range_min: Optional[int] = Field(None, gt=0)
    target_price_range_max: Optional[int] = Field(None, gt=0)
    is_active: Optional[bool] = None
    discount_id: Optional[int] = Field(None, gt=0)


class PromotionResponse(PromotionBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    # Nested objects
    discount: Optional['DiscountResponse'] = None

    class Config:
        from_attributes = True