from .apartment_type import ApartmentTypeCreate, ApartmentTypeUpdate, ApartmentTypeResponse
from .building import BuildingCreate, BuildingUpdate, BuildingResponse
from .owner import OwnerCreate, OwnerUpdate, OwnerResponse
from .renter import RenterCreate, RenterUpdate, RenterResponse
from .apartment import ApartmentCreate, ApartmentUpdate, ApartmentResponse
from .rental import RentalCreate, RentalUpdate, RentalResponse
from .sale import SaleCreate, SaleUpdate, SaleResponse
from .discount import DiscountCreate, DiscountUpdate, DiscountResponse
from .promotion import PromotionCreate, PromotionUpdate, PromotionResponse
from app.schemas.payment import PaymentCreate, PaymentUpdate, PaymentResponse
from app.schemas.review import ReviewCreate, ReviewUpdate,ReviewResponse
from app.schemas.support_ticket import SupportTicketCreate, SupportTicketUpdate