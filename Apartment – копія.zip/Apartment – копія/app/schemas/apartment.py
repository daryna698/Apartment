from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum


class ApartmentStatusEnum(str, Enum):
    AVAILABLE = "available"
    RENTED = "rented"
    SOLD = "sold"
    MAINTENANCE = "maintenance"
    RESERVED = "reserved"


class ApartmentBase(BaseModel):
    number: str = Field(..., min_length=1, max_length=20, description="Номер квартири")
    floor: int = Field(..., ge=1, le=200, description="Поверх")
    rooms_count: int = Field(..., ge=1, le=20, description="Кількість кімнат")

    total_area: float = Field(..., gt=0, le=1000, description="Загальна площа в м²")
    living_area: Optional[float] = Field(None, gt=0, le=1000, description="Житлова площа в м²")
    kitchen_area: Optional[float] = Field(None, gt=0, le=100, description="Площа кухні в м²")

    bathroom_count: int = Field(1, ge=1, le=10, description="Кількість санвузлів")
    balcony: bool = Field(False, description="Наявність балкону")
    loggia: bool = Field(False, description="Наявність лоджії")
    separate_bathroom: bool = Field(False, description="Роздільний санвузол")

    renovation_type: Optional[str] = Field(None, max_length=50, description="Тип ремонту")
    furnished: bool = Field(False, description="Мебльована")
    appliances: Optional[str] = Field(None, description="Список техніки")

    rent_price: Optional[int] = Field(None, ge=0, description="Ціна оренди в копійках")
    sale_price: Optional[int] = Field(None, ge=0, description="Ціна продажу в копійках")
    utilities_included: bool = Field(False, description="Комунальні включені")

    status: ApartmentStatusEnum = Field(ApartmentStatusEnum.AVAILABLE, description="Статус квартири")

    description: Optional[str] = Field(None, description="Опис квартири")
    notes: Optional[str] = Field(None, description="Внутрішні нотатки")
    images: Optional[List[str]] = Field(None, description="URL зображень")

    building_id: int = Field(..., gt=0, description="ID будівлі")
    owner_id: int = Field(..., gt=0, description="ID власника")
    apartment_type_id: int = Field(..., gt=0, description="ID типу квартири")

    @validator('living_area')
    def validate_living_area(cls, v, values):
        if v is not None and 'total_area' in values and v >= values['total_area']:
            raise ValueError('Житлова площа не може бути більше або рівна загальній площі')
        return v

    @validator('kitchen_area')
    def validate_kitchen_area(cls, v, values):
        if v is not None and 'total_area' in values and v >= values['total_area']:
            raise ValueError('Площа кухні не може бути більше або рівна загальній площі')
        return v


class ApartmentCreate(ApartmentBase):
    pass


class ApartmentUpdate(BaseModel):
    number: Optional[str] = Field(None, min_length=1, max_length=20)
    floor: Optional[int] = Field(None, ge=1, le=200)
    rooms_count: Optional[int] = Field(None, ge=1, le=20)
    total_area: Optional[float] = Field(None, gt=0, le=1000)
    living_area: Optional[float] = Field(None, gt=0, le=1000)
    kitchen_area: Optional[float] = Field(None, gt=0, le=100)
    bathroom_count: Optional[int] = Field(None, ge=1, le=10)
    balcony: Optional[bool] = None
    loggia: Optional[bool] = None
    separate_bathroom: Optional[bool] = None
    renovation_type: Optional[str] = Field(None, max_length=50)
    furnished: Optional[bool] = None
    appliances: Optional[str] = None
    rent_price: Optional[int] = Field(None, ge=0)
    sale_price: Optional[int] = Field(None, ge=0)
    utilities_included: Optional[bool] = None
    status: Optional[ApartmentStatusEnum] = None
    description: Optional[str] = None
    notes: Optional[str] = None
    images: Optional[List[str]] = None
    building_id: Optional[int] = Field(None, gt=0)
    owner_id: Optional[int] = Field(None, gt=0)
    apartment_type_id: Optional[int] = Field(None, gt=0)


class ApartmentResponse(ApartmentBase):
    id: int
    full_address: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    # Nested objects
    building: Optional['BuildingResponse'] = None
    owner: Optional['OwnerResponse'] = None
    apartment_type: Optional['ApartmentTypeResponse'] = None

    class Config:
        from_attributes = True