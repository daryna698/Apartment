from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime
from enum import Enum


class SaleStatusEnum(str, Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class SaleBase(BaseModel):
    sale_price: int = Field(..., gt=0, description="Ціна продажу в копійках")
    sale_date: datetime = Field(..., description="Дата продажу")
    contract_date: Optional[datetime] = Field(None, description="Дата підписання договору")

    status: SaleStatusEnum = Field(SaleStatusEnum.PENDING, description="Статус продажу")

    commission_rate: int = Field(0, ge=0, le=10000, description="Відсоток комісії * 100")
    commission_amount: int = Field(0, ge=0, description="Сума комісії в копійках")

    notes: Optional[str] = Field(None, description="Додаткові нотатки")
    cancellation_reason: Optional[str] = Field(None, description="Причина скасування")

    apartment_id: int = Field(..., gt=0, description="ID квартири")
    seller_id: int = Field(..., gt=0, description="ID продавця")
    buyer_id: int = Field(..., gt=0, description="ID покупця")

    @validator('contract_date')
    def validate_contract_date(cls, v, values):
        if v is not None and 'sale_date' in values and v > values['sale_date']:
            raise ValueError('Дата договору не може бути пізніше дати продажу')
        return v

    @validator('commission_amount')
    def validate_commission_amount(cls, v, values):
        if 'sale_price' in values and 'commission_rate' in values:
            expected_commission = (values['sale_price'] * values['commission_rate']) // 10000
            if v != 0 and abs(v - expected_commission) > 100:  # допускаємо розбіжність в 1 грн
                raise ValueError('Сума комісії не відповідає відсотку комісії')
        return v


class SaleCreate(SaleBase):
    pass


class SaleUpdate(BaseModel):
    sale_price: Optional[int] = Field(None, gt=0)
    sale_date: Optional[datetime] = None
    contract_date: Optional[datetime] = None
    status: Optional[SaleStatusEnum] = None
    commission_rate: Optional[int] = Field(None, ge=0, le=10000)
    commission_amount: Optional[int] = Field(None, ge=0)
    notes: Optional[str] = None
    cancellation_reason: Optional[str] = None
    apartment_id: Optional[int] = Field(None, gt=0)
    seller_id: Optional[int] = Field(None, gt=0)
    buyer_id: Optional[int] = Field(None, gt=0)


class SaleResponse(SaleBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    # Nested objects
    apartment: Optional['ApartmentResponse'] = None
    seller: Optional['OwnerResponse'] = None
    buyer: Optional['RenterResponse'] = None

    class Config:
        from_attributes = True
