from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional
from datetime import datetime, date
import re


class RenterBase(BaseModel):
    first_name: str = Field(..., min_length=1, max_length=100, description="Ім'я")
    last_name: str = Field(..., min_length=1, max_length=100, description="Прізвище")
    middle_name: Optional[str] = Field(None, max_length=100, description="По батькові")
    birth_date: Optional[date] = Field(None, description="Дата народження")

    email: EmailStr = Field(..., description="Email адреса")
    phone: str = Field(..., min_length=10, max_length=20, description="Номер телефону")
    alternative_phone: Optional[str] = Field(None, min_length=10, max_length=20, description="Альтернативний телефон")

    current_address: Optional[str] = Field(None, max_length=500, description="Поточна адреса")
    city: Optional[str] = Field(None, max_length=100, description="Місто")

    workplace: Optional[str] = Field(None, max_length=200, description="Місце роботи")
    position: Optional[str] = Field(None, max_length=100, description="Посада")
    monthly_income: Optional[int] = Field(None, ge=0, description="Місячний дохід в копійках")

    notes: Optional[str] = Field(None, description="Додаткові нотатки")
    is_active: bool = Field(True, description="Активний статус")

    class SomeModel(BaseModel):
        phone: Optional[str]
        alternative_phone: Optional[str]

        @validator('phone', 'alternative_phone')
        def validate_phone(cls, v):
            if v is None:
                return v
            # Видаляємо пробіли та дефіси
            cleaned = v.replace(' ', '').replace('-', '')
            # Простий регекс для українських номерів телефону
            if not re.match(r'^(\+38)?0\d{9}$', cleaned):
                raise ValueError('Невірний формат номера телефону. Очікується: +380XXXXXXXXX або 0XXXXXXXXX')
            return v

    @validator('birth_date')
    def validate_birth_date(cls, v):
        if v is None:
            return v
        if v >= date.today():
            raise ValueError('Дата народження не може бути в майбутньому')
        if (date.today() - v).days < 18 * 365:
            raise ValueError('Орендар повинен бути повнолітнім')
        return v


class RenterCreate(RenterBase):
    pass


class RenterUpdate(BaseModel):
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    middle_name: Optional[str] = Field(None, max_length=100)
    birth_date: Optional[date] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, min_length=10, max_length=20)
    alternative_phone: Optional[str] = Field(None, min_length=10, max_length=20)
    current_address: Optional[str] = Field(None, max_length=500)
    city: Optional[str] = Field(None, max_length=100)
    workplace: Optional[str] = Field(None, max_length=200)
    position: Optional[str] = Field(None, max_length=100)
    monthly_income: Optional[int] = Field(None, ge=0)
    notes: Optional[str] = None
    is_active: Optional[bool] = None

class RenterResponse(RenterBase):
    id: int
    full_name: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True