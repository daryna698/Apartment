from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime


class SupportTicketBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: str = Field(..., min_length=1)
    category: Optional[str] = Field(None, max_length=100)
    priority: str = Field("medium", max_length=50)
    status: str = Field("open", max_length=50)
    resolution: Optional[str] = None
    resolved_at: Optional[datetime] = None
    apartment_id: int


class SupportTicketCreate(SupportTicketBase):
    pass


class SupportTicketUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, min_length=1)
    category: Optional[str] = Field(None, max_length=100)
    priority: Optional[str] = Field(None, max_length=50)
    status: Optional[str] = Field(None, max_length=50)
    resolution: Optional[str] = None
    resolved_at: Optional[datetime] = None
    apartment_id: Optional[int] = None


class SupportTicketInDB(SupportTicketBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None


class SupportTicketRead(SupportTicketInDB):
    pass


class SupportTicketResponse:
    pass