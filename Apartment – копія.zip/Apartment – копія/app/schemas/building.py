from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime


class BuildingBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200, description="Назва будівлі")
    address: str = Field(..., min_length=1, max_length=500, description="Адреса")
    city: str = Field(..., min_length=1, max_length=100, description="Місто")
    district: Optional[str] = Field(None, max_length=100, description="Район")
    postal_code: Optional[str] = Field(None, max_length=20, description="Поштовий код")

    floors_count: Optional[int] = Field(None, ge=1, le=200, description="Кількість поверхів")
    year_built: Optional[int] = Field(None, ge=1800, le=2030, description="Рік будівництва")
    elevator: bool = Field(False, description="Наявність ліфта")
    parking: bool = Field(False, description="Наявність паркінгу")
    security: bool = Field(False, description="Наявність охорони")

    latitude: Optional[float] = Field(None, ge=-90, le=90, description="Широта")
    longitude: Optional[float] = Field(None, ge=-180, le=180, description="Довгота")

    description: Optional[str] = Field(None, description="Опис будівлі")
    is_active: bool = Field(True, description="Активний статус")


class BuildingCreate(BuildingBase):
    pass


class BuildingUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    address: Optional[str] = Field(None, min_length=1, max_length=500)
    city: Optional[str] = Field(None, min_length=1, max_length=100)
    district: Optional[str] = Field(None, max_length=100)
    postal_code: Optional[str] = Field(None, max_length=20)
    floors_count: Optional[int] = Field(None, ge=1, le=200)
    year_built: Optional[int] = Field(None, ge=1800, le=2030)
    elevator: Optional[bool] = None
    parking: Optional[bool] = None
    security: Optional[bool] = None
    latitude: Optional[float] = Field(None, ge=-90, le=90)
    longitude: Optional[float] = Field(None, ge=-180, le=180)
    description: Optional[str] = None
    is_active: Optional[bool] = None


class BuildingResponse(BuildingBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
