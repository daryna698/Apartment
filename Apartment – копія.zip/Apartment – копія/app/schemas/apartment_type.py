from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class ApartmentTypeBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="Назва типу квартири")
    description: Optional[str] = Field(None, description="Опис типу квартири")
    is_active: bool = Field(True, description="Активний статус")


class ApartmentTypeCreate(ApartmentTypeBase):
    pass


class ApartmentTypeUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = None
    is_active: Optional[bool] = None


class ApartmentTypeResponse(ApartmentTypeBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True