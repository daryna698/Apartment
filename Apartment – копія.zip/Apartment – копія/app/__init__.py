
__version__ = "1.0.0"
__title__ = "EliteSpace API"
__description__ = "API для управління нерухомістю, орендою та продажем квартир"
__author__ = "EliteSpace Properies"
