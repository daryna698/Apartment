from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime

from app.models.promotion import Promotion
from app.repositories.promotion import PromotionRepository
from app.schemas.promotion import PromotionCreate, PromotionUpdate
from .base_service import BaseService


class PromotionService(BaseService[Promotion, PromotionCreate, PromotionUpdate]):
    def __init__(self, repository: PromotionRepository):
        super().__init__(repository)
        self.repository = repository

    async def get_active_promotions(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Promotion]:
        """Отримати активні акції"""
        return await self.repository.get_active_promotions(db, skip, limit)

    async def get_promotions_by_apartment(
            self,
            db: Session,
            apartment_id: int,
            skip: int = 0,
            limit: int = 100
    ) -> List[Promotion]:
        """Отримати акції для квартири"""
        return await self.repository.get_by_apartment(db, apartment_id, skip, limit)

    async def apply_promotion(
            self,
            db: Session,
            promotion_id: int,
            apartment_id: int
    ) -> Optional[Promotion]:
        """Застосувати акцію до квартири"""
        promotion = await self.get_by_id(db, promotion_id)

        if not promotion or not promotion.is_active:
            return None

        if promotion.start_date > datetime.now() or promotion.end_date < datetime.now():
            return None

        # Перевірити, чи не застосована вже ця акція
        existing = await self.repository.get_by_apartment_and_promotion(
            db, apartment_id, promotion_id
        )

        if existing:
            return None

        # Логіка прив'язки акції до квартири
        # Можна додати окрему таблицю apartment_promotions
        return promotion

    async def deactivate_expired_promotions(self, db: Session) -> int:
        """Деактивувати прострочені акції"""
        return await self.repository.deactivate_expired(db)
