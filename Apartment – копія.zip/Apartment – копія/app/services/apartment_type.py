from typing import List, Optional
from sqlalchemy.orm import Session

from app.models.apartment_type import ApartmentType
from app.repositories.apartment_type import ApartmentTypeRepository
from app.schemas.apartment_type import ApartmentTypeCreate, ApartmentTypeUpdate
from .base_service import BaseService

class ApartmentTypeService(BaseService[ApartmentType, ApartmentTypeCreate, ApartmentTypeUpdate]):
    def __init__(self, repository: ApartmentTypeRepository):
        super().__init__(repository)
        self.repository = repository

    async def get_active_types(
        self,
        db: Session,
        skip: int = 0,
        limit: int = 100
    ) -> List[ApartmentType]:
        """Отримати активні типи квартир"""
        return await self.repository.get_active_types(db, skip, limit)

    async def get_by_name(self, db: Session, name: str) -> Optional[ApartmentType]:
        """Отримати тип квартири за назвою"""
        return await self.repository.get_by_name(db, name)

    async def toggle_active_status(
        self,
        db: Session,
        type_id: int
    ) -> Optional[ApartmentType]:
        """Змінити статус активності типу"""
        apartment_type = await self.get_by_id(db, type_id)
        if apartment_type:
            apartment_type.is_active = not apartment_type.is_active
            db.commit()
            db.refresh(apartment_type)
        return apartment_type