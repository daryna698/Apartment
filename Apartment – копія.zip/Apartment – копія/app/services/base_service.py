from typing import Generic, TypeVar, List, Optional, Type, Any, Dict
from sqlalchemy.orm import Session
from pydantic import BaseModel
from app.repositories.base import BaseRepository

# Типізація
ModelType = TypeVar("ModelType")
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class BaseService(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    """Базовий сервіс для всіх моделей"""

    def __init__(self, repository: BaseRepository[ModelType]):
        self.repository = repository

    async def get_by_id(self, id: int) -> Optional[ModelType]:
        """Отримати об'єкт за ID"""
        return self.repository.get_by_id(id)

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[ModelType]:
        """Отримати всі об'єкти"""
        return self.repository.get_all(skip=skip, limit=limit)

    async def create(self, obj_data: CreateSchemaType) -> ModelType:
        """Створити новий об'єкт"""
        return self.repository.create(obj_data)

    async def update(self, id: int, obj_data: UpdateSchemaType) -> Optional[ModelType]:
        """Оновити об'єкт"""
        db_obj = self.repository.get_by_id(id)
        if not db_obj:
            return None

        return self.repository.update(db_obj, obj_data)

    async def delete(self, id: int) -> bool:
        """Видалити об'єкт"""
        return self.repository.delete(id)

    async def exists(self, id: int) -> bool:
        """Перевірити існування об'єкта"""
        return self.repository.exists(id)

    async def count(self) -> int:
        """Підрахунок кількості записів"""
        return self.repository.count()
