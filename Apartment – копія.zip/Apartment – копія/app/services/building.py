from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from app.models.building import Building
from app.repositories.building import BuildingRepository
from app.schemas.building import BuildingCreate, BuildingUpdate
from .base_service import BaseService


class BuildingService(BaseService[Building, BuildingCreate, BuildingUpdate]):
    def __init__(self, repository: BuildingRepository):
        super().__init__(repository)
        self.repository = repository

    async def get_buildings_by_city(
            self,
            db: Session,
            city: str,
            skip: int = 0,
            limit: int = 100
    ) -> List[Building]:
        """Отримати будівлі по місту"""
        return await self.repository.get_by_city(db, city, skip, limit)

    async def search_buildings(
            self,
            db: Session,
            city: Optional[str] = None,
            district: Optional[str] = None,
            has_elevator: Optional[bool] = None,
            has_parking: Optional[bool] = None,
            has_security: Optional[bool] = None,
            min_floors: Optional[int] = None,
            max_floors: Optional[int] = None,
            skip: int = 0,
            limit: int = 100
    ) -> List[Building]:
        """Розширений пошук будівель"""
        return await self.repository.search_buildings(
            db=db, city=city, district=district, has_elevator=has_elevator,
            has_parking=has_parking, has_security=has_security,
            min_floors=min_floors, max_floors=max_floors,
            skip=skip, limit=limit
        )

    async def get_building_statistics(self, db: Session, building_id: int) -> Dict[str, Any]:
        """Отримати статистику будівлі"""
        building = await self.get_by_id(db, building_id)
        if not building:
            return {}

        # Підрахувати квартири в будівлі
        from app.repositories.apartment import ApartmentRepository
        apartment_repo = ApartmentRepository()

        total_apartments = await apartment_repo.count_by_building(db, building_id)
        available_apartments = await apartment_repo.count_available_by_building(db, building_id)

        return {
            "building_info": {
                "id": building.id,
                "name": building.name,
                "address": building.address,
                "city": building.city
            },
            "apartments": {
                "total": total_apartments,
                "available": available_apartments,
                "occupied": total_apartments - available_apartments
            },
            "facilities": {
                "elevator": building.elevator,
                "parking": building.parking,
                "security": building.security
            }
        }