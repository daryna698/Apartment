from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.models.payment import Payment, PaymentStatus, PaymentType
from app.repositories.payment import PaymentRepository
from app.schemas.payment import PaymentCreate, PaymentUpdate
from .base_service import BaseService


class PaymentService(BaseService[Payment, PaymentCreate, PaymentUpdate]):
    def __init__(self, repository: PaymentRepository):
        super().__init__(repository)
        self.repository = repository

    async def process_payment(self, db: Session, payment_id: int) -> Optional[Payment]:
        """Обробити платіж"""
        payment = await self.get_by_id(db, payment_id)
        if not payment:
            return None

        payment.status = PaymentStatus.COMPLETED
        payment.payment_date = datetime.now()

        db.commit()
        db.refresh(payment)
        return payment

    async def get_overdue_payments(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Payment]:
        """Отримати прострочені платежі"""
        return await self.repository.get_overdue_payments(db, skip, limit)

    async def get_payments_by_rental(
            self,
            db: Session,
            rental_id: int,
            skip: int = 0,
            limit: int = 100
    ) -> List[Payment]:
        """Отримати платежі по оренді"""
        return await self.repository.get_by_rental(db, rental_id, skip, limit)

    async def create_monthly_rent_payment(
            self,
            db: Session,
            rental_id: int,
            month: datetime
    ) -> Payment:
        """Створити місячний платіж за оренду"""
        # Отримати інформацію про оренду
        from app.repositories.rental import RentalRepository
        rental_repo = RentalRepository()
        rental = await rental_repo.get_by_id(db, rental_id)

        if not rental:
            raise ValueError("Оренда не знайдена")

        # Створити платіж
        payment_data = PaymentCreate(
            amount=rental.monthly_rent,
            payment_type=PaymentType.RENT,
            due_date=month.replace(day=1) + timedelta(days=32),  # Кінець місяця
            rental_id=rental_id
        )

        return await self.create(db, payment_data)