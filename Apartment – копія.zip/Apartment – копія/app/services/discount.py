from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime

from app.models.discount import Discount, DiscountType
from app.repositories.discount import DiscountRepository
from app.schemas.discount import DiscountCreate, DiscountUpdate
from .base_service import BaseService


class DiscountService(BaseService[Discount, DiscountCreate, DiscountUpdate]):
    def __init__(self, repository: DiscountRepository):
        super().__init__(repository)
        self.repository = repository

    async def get_active_discounts(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Discount]:
        """Отримати активні знижки"""
        return await self.repository.get_active_discounts(db, skip, limit)

    async def apply_discount(
            self,
            db: Session,
            discount_id: int,
            rental_price: int,
            rental_period: Optional[int] = None
    ) -> Optional[int]:
        """Застосувати знижку до ціни оренди"""
        discount = await self.get_by_id(db, discount_id)

        if not discount or not discount.is_active:
            return None

        # Перевірити умови застосування
        if discount.min_rental_period and rental_period and rental_period < discount.min_rental_period:
            return None

        if discount.min_apartment_price and rental_price < discount.min_apartment_price:
            return None

        # Перевірити ліміт використання
        if discount.max_uses and discount.current_uses >= discount.max_uses:
            return None

        # Розрахувати знижку
        if discount.discount_type == DiscountType.PERCENTAGE:
            discount_amount = (rental_price * discount.value) // 10000
        else:  # FIXED_AMOUNT
            discount_amount = discount.value

        # Оновити кількість використань
        discount.current_uses += 1
        db.commit()

        return rental_price - discount_amount

    async def validate_discount_code(self, db: Session, code: str) -> Optional[Discount]:
        """Перевірити код знижки"""
        return await self.repository.get_by_code(db, code)
