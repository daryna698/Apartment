from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from app.models.owner import Owner
from app.repositories.owner import OwnerRepository
from app.schemas.owner import OwnerCreate, OwnerUpdate
from .base_service import BaseService


class OwnerService(BaseService[Owner, OwnerCreate, OwnerUpdate]):
    def __init__(self, repository: OwnerRepository):
        super().__init__(repository)
        self.repository = repository

    async def get_by_email(self, db: Session, email: str) -> Optional[Owner]:
        """Отримати власника за email"""
        return await self.repository.get_by_email(db, email)

    async def search_owners(
            self,
            db: Session,
            search_term: str,
            skip: int = 0,
            limit: int = 100
    ) -> List[Owner]:
        """Пошук власників за ім'ям або email"""
        return await self.repository.search_owners(db, search_term, skip, limit)

    async def get_owner_portfolio(self, db: Session, owner_id: int) -> Dict[str, Any]:
        """Отримати портфоліо власника"""
        owner = await self.get_by_id(db, owner_id)
        if not owner:
            return {}

        from app.repositories.apartment import ApartmentRepository
        from app.repositories.rental import RentalRepository
        from app.repositories.sale import SaleRepository

        apartment_repo = ApartmentRepository()
        rental_repo = RentalRepository()
        sale_repo = SaleRepository()

        # Статистика квартир
        total_apartments = await apartment_repo.count_by_owner(db, owner_id)
        available_apartments = await apartment_repo.count_available_by_owner(db, owner_id)

        # Дохід від оренди
        rental_income = await rental_repo.calculate_income(db, owner_id)

        # Продажі
        sales_volume = await sale_repo.calculate_sales_volume_by_owner(db, owner_id)

        return {
            "owner_info": {
                "id": owner.id,
                "name": owner.full_name,
                "email": owner.email,
                "phone": owner.phone
            },
            "properties": {
                "total_apartments": total_apartments,
                "available_apartments": available_apartments,
                "rented_apartments": total_apartments - available_apartments
            },
            "financial": {
                "rental_income": rental_income,
                "sales_volume": sales_volume
            }
        }
