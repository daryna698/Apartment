from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from app.models.renter import Renter
from app.repositories.renter import RenterRepository
from app.schemas.renter import RenterCreate, RenterUpdate
from .base_service import BaseService


class RenterService(BaseService[Renter, RenterCreate, RenterUpdate]):
    def __init__(self, repository: RenterRepository):
        super().__init__(repository)
        self.repository = repository

    async def get_by_email(self, db: Session, email: str) -> Optional[Renter]:
        """Отримати орендаря за email"""
        return await self.repository.get_by_email(db, email)

    async def search_renters(
            self,
            db: Session,
            search_term: str,
            skip: int = 0,
            limit: int = 100
    ) -> List[Renter]:
        """Пошук орендарів за ім'ям або email"""
        return await self.repository.search_renters(db, search_term, skip, limit)

    async def get_renter_history(self, db: Session, renter_id: int) -> Dict[str, Any]:
        """Отримати історію орендаря"""
        renter = await self.get_by_id(db, renter_id)
        if not renter:
            return {}

        from app.repositories.rental import RentalRepository
        from app.repositories.payment import PaymentRepository
        from app.repositories.review import ReviewRepository

        rental_repo = RentalRepository()
        payment_repo = PaymentRepository()
        review_repo = ReviewRepository()

        # Статистика оренд
        total_rentals = await rental_repo.count_by_renter(db, renter_id)
        active_rentals = await rental_repo.count_active_by_renter(db, renter_id)

        # Платежі
        total_payments = await payment_repo.calculate_total_by_renter(db, renter_id)
        overdue_payments = await payment_repo.count_overdue_by_renter(db, renter_id)

        # Відгуки
        reviews_count = await review_repo.count_by_renter(db, renter_id)

        return {
            "renter_info": {
                "id": renter.id,
                "name": renter.full_name,
                "email": renter.email,
                "phone": renter.phone
            },
            "rental_history": {
                "total_rentals": total_rentals,
                "active_rentals": active_rentals,
                "total_payments": total_payments,
                "overdue_payments": overdue_payments
            },
            "engagement": {
                "reviews_count": reviews_count
            }
        }