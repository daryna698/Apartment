from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from datetime import datetime

from app.models.review import Review
from app.repositories.review import ReviewRepository
from app.schemas.review import ReviewCreate, ReviewUpdate
from .base_service import BaseService


class ReviewService(BaseService[Review, ReviewCreate, ReviewUpdate]):
    def __init__(self, repository: ReviewRepository):
        super().__init__(repository)
        self.repository = repository

    async def create_review(self, db: Session, review_data: ReviewCreate) -> Review:
        """Створити новий відгук"""
        # Перевірити, чи не залишив користувач вже відгук для цієї квартири
        existing_review = await self.repository.get_by_renter_and_apartment(
            db, review_data.renter_id, review_data.apartment_id
        )

        if existing_review:
            raise ValueError("Відгук для цієї квартири вже існує")

        return await self.create(db, review_data)

    async def get_reviews_by_apartment(
            self,
            db: Session,
            apartment_id: int,
            skip: int = 0,
            limit: int = 100
    ) -> List[Review]:
        """Отримати відгуки по квартирі"""
        return await self.repository.get_by_apartment(db, apartment_id, skip, limit)

    async def get_reviews_by_renter(
            self,
            db: Session,
            renter_id: int,
            skip: int = 0,
            limit: int = 100
    ) -> List[Review]:
        """Отримати відгуки орендаря"""
        return await self.repository.get_by_renter(db, renter_id, skip, limit)

    async def get_apartment_rating(self, db: Session, apartment_id: int) -> Optional[float]:
        """Отримати середній рейтинг квартири"""
        return await self.repository.get_average_rating(db, apartment_id)

    async def get_reviews_statistics(self, db: Session) -> Dict[str, Any]:
        """Отримати статистику відгуків"""
        total_reviews = await self.repository.count_all(db)
        avg_rating = await self.repository.get_overall_average_rating(db)

        return {
            "total_reviews": total_reviews,
            "average_rating": avg_rating,
            "rating_distribution": await self.repository.get_rating_distribution(db)
        }