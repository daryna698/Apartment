from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.models.rental import Rental, RentalStatus
from app.models.apartment import ApartmentStatus
from app.repositories.rental import RentalRepository
from app.repositories.apartment import ApartmentRepository
from app.schemas.rental import RentalCreate, RentalUpdate
from .base_service import BaseService


class RentalService(BaseService[Rental, RentalCreate, RentalUpdate]):
    def __init__(self, rental_repo: RentalRepository, apartment_repo: ApartmentRepository):
        super().__init__(rental_repo)
        self.rental_repo = rental_repo
        self.apartment_repo = apartment_repo

    async def create_rental(self, db: Session, rental_data: RentalCreate) -> Optional[Rental]:
        """Створити нову оренду з перевіркою доступності"""
        # Перевірити доступність квартири
        apartment = await self.apartment_repo.get_by_id(db, rental_data.apartment_id)
        if not apartment or apartment.status != ApartmentStatus.AVAILABLE:
            return None

        # Створити оренду
        rental = await self.create(db, rental_data)

        # Оновити статус квартири
        await self.apartment_repo.update_status(db, rental_data.apartment_id, ApartmentStatus.RENTED)

        return rental

    async def complete_rental(self, db: Session, rental_id: int) -> Optional[Rental]:
        """Завершити оренду"""
        rental = await self.get_by_id(db, rental_id)
        if not rental:
            return None

        rental.status = RentalStatus.COMPLETED
        # Повернути квартиру в доступний статус
        await self.apartment_repo.update_status(db, rental.apartment_id, ApartmentStatus.AVAILABLE)

        db.commit()
        db.refresh(rental)
        return rental

    async def get_active_rentals(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Rental]:
        """Отримати активні оренди"""
        return await self.rental_repo.get_by_status(db, RentalStatus.ACTIVE, skip, limit)

    async def get_expiring_rentals(
            self,
            db: Session,
            days_ahead: int = 30,
            skip: int = 0,
            limit: int = 100
    ) -> List[Rental]:
        """Отримати оренди, що закінчуються найближчим часом"""
        end_date = datetime.now() + timedelta(days=days_ahead)
        return await self.rental_repo.get_expiring_rentals(db, end_date, skip, limit)

    async def get_rentals_by_renter(
            self,
            db: Session,
            renter_id: int,
            skip: int = 0,
            limit: int = 100
    ) -> List[Rental]:
        """Отримати оренди орендаря"""
        return await self.rental_repo.get_by_renter(db, renter_id, skip, limit)

    async def calculate_total_income(
            self,
            db: Session,
            owner_id: Optional[int] = None,
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None
    ) -> int:
        """Розрахувати загальний дохід від оренди"""
        return await self.rental_repo.calculate_income(db, owner_id, start_date, end_date)
