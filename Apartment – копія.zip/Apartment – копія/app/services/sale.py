from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime

from app.models.sale import Sale, SaleStatus
from app.models.apartment import ApartmentStatus
from app.repositories.sale import SaleRepository
from app.repositories.apartment import ApartmentRepository
from app.schemas.sale import SaleCreate, SaleUpdate
from .base_service import BaseService


class SaleService(BaseService[Sale, SaleCreate, SaleUpdate]):
    def __init__(self, sale_repo: SaleRepository, apartment_repo: ApartmentRepository):
        super().__init__(sale_repo)
        self.sale_repo = sale_repo
        self.apartment_repo = apartment_repo

    async def create_sale(self, db: Session, sale_data: SaleCreate) -> Optional[Sale]:
        """Створити новий продаж"""
        # Перевірити доступність квартири
        apartment = await self.apartment_repo.get_by_id(db, sale_data.apartment_id)
        if not apartment or apartment.status == ApartmentStatus.SOLD:
            return None

        # Розрахувати комісію
        commission_amount = (sale_data.sale_price * sale_data.commission_rate) // 10000

        sale_data_dict = sale_data.dict()
        sale_data_dict['commission_amount'] = commission_amount

        sale = await self.create(db, sale_data_dict)

        # Оновити статус квартири
        await self.apartment_repo.update_status(db, sale_data.apartment_id, ApartmentStatus.SOLD)

        return sale

    async def complete_sale(self, db: Session, sale_id: int) -> Optional[Sale]:
        """Завершити продаж"""
        sale = await self.get_by_id(db, sale_id)
        if not sale:
            return None

        sale.status = SaleStatus.COMPLETED
        sale.contract_date = datetime.now()

        db.commit()
        db.refresh(sale)
        return sale

    async def cancel_sale(self, db: Session, sale_id: int, reason: str) -> Optional[Sale]:
        """Скасувати продаж"""
        sale = await self.get_by_id(db, sale_id)
        if not sale:
            return None

        sale.status = SaleStatus.CANCELLED
        sale.cancellation_reason = reason

        # Повернути квартиру в доступний статус
        await self.apartment_repo.update_status(db, sale.apartment_id, ApartmentStatus.AVAILABLE)

        db.commit()
        db.refresh(sale)
        return sale

    async def get_completed_sales(
            self,
            db: Session,
            skip: int = 0,
            limit: int = 100
    ) -> List[Sale]:
        """Отримати завершені продажі"""
        return await self.sale_repo.get_by_status(db, SaleStatus.COMPLETED, skip, limit)

    async def calculate_total_sales_volume(
            self,
            db: Session,
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None
    ) -> int:
        """Розрахувати загальний обсяг продажів"""
        return await self.sale_repo.calculate_sales_volume(db, start_date, end_date)

    async def calculate_total_commission(
            self,
            db: Session,
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None
    ) -> int:
        """Розрахувати загальну комісію"""
        return await self.sale_repo.calculate_commission(db, start_date, end_date)
