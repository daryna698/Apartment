from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from collections import defaultdict

from app.repositories.apartment import ApartmentRepository
from app.repositories.rental import RentalRepository
from app.repositories.sale import SaleRepository
from app.repositories.payment import PaymentRepository


class AnalyticsService:
    def __init__(
            self,
            apartment_repo: ApartmentRepository,
            rental_repo: RentalRepository,
            sale_repo: SaleRepository,
            payment_repo: PaymentRepository
    ):
        self.apartment_repo = apartment_repo
        self.rental_repo = rental_repo
        self.sale_repo = sale_repo
        self.payment_repo = payment_repo

    async def get_dashboard_stats(self, db: Session) -> Dict[str, Any]:
        """Отримати статистику для головної панелі"""
        # Загальна кількість квартир
        total_apartments = await self.apartment_repo.count_all(db)
        available_apartments = await self.apartment_repo.count_by_status(db, "AVAILABLE")
        rented_apartments = await self.apartment_repo.count_by_status(db, "RENTED")
        sold_apartments = await self.apartment_repo.count_by_status(db, "SOLD")

        # Активні оренди
        active_rentals = await self.rental_repo.count_by_status(db, "ACTIVE")

        # Дохід за поточний місяць
        current_month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        monthly_income = await self.rental_repo.calculate_income(
            db, start_date=current_month_start
        )

        return {
            "apartments": {
                "total": total_apartments,
                "available": available_apartments,
                "rented": rented_apartments,
                "sold": sold_apartments
            },
            "rentals": {
                "active": active_rentals
            },
            "income": {
                "current_month": monthly_income
            }
        }

    async def get_rental_analytics(
            self,
            db: Session,
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Аналітика по орендах"""
        if not start_date:
            start_date = datetime.now() - timedelta(days=30)
        if not end_date:
            end_date = datetime.now()

        # Загальний дохід
        total_income = await self.rental_repo.calculate_income(db, None, start_date, end_date)

        # Середня ціна оренди
        avg_rent = await self.rental_repo.get_average_rent(db)

        # Статистика по платежах
        payment_stats = await self.payment_repo.get_payment_statistics(db, start_date, end_date)

        return {
            "total_income": total_income,
            "average_rent": avg_rent,
            "payment_statistics": payment_stats,
            "period": {
                "start_date": start_date,
                "end_date": end_date
            }
        }

    async def get_sales_analytics(
            self,
            db: Session,
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Аналітика по продажах"""
        if not start_date:
            start_date = datetime.now() - timedelta(days=30)
        if not end_date:
            end_date = datetime.now()

        # Загальний обсяг продажів
        sales_volume = await self.sale_repo.calculate_sales_volume(db, start_date, end_date)

        # Загальна комісія
        total_commission = await self.sale_repo.calculate_commission(db, start_date, end_date)

        # Кількість продажів
        sales_count = await self.sale_repo.count_sales(db, start_date, end_date)

        return {
            "sales_volume": sales_volume,
            "total_commission": total_commission,
            "sales_count": sales_count,
            "average_sale_price": sales_volume // sales_count if sales_count > 0 else 0,
            "period": {
                "start_date": start_date,
                "end_date": end_date
            }
        }

    async def get_property_analytics(self, db: Session) -> Dict[str, Any]:
        """Аналітика по нерухомості"""
        # Статистика по типах квартир
        apartment_types_stats = await self.apartment_repo.get_stats_by_type(db)

        # Статистика по містах
        cities_stats = await self.apartment_repo.get_stats_by_city(db)

        # Розподіл за кількістю кімнат
        rooms_distribution = await self.apartment_repo.get_rooms_distribution(db)

        return {
            "apartment_types": apartment_types_stats,
            "cities": cities_stats,
            "rooms_distribution": rooms_distribution
        }
