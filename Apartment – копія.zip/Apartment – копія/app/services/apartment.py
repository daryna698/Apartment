from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from decimal import Decimal

from app.models.apartment import Apartment, ApartmentStatus
from app.repositories.apartment import ApartmentRepository
from app.schemas.apartment import ApartmentCreate, ApartmentUpdate
from .base_service import BaseService

class ApartmentService(BaseService[Apartment, ApartmentCreate, ApartmentUpdate]):
    def __init__(self, repository: ApartmentRepository):
        super().__init__(repository)
        self.repository = repository

    async def get_available_apartments(
        self,
        db: Session,
        skip: int = 0,
        limit: int = 100
    ) -> List[Apartment]:
        """Отримати доступні для оренди квартири"""
        return await self.repository.get_by_status(db, ApartmentStatus.AVAILABLE, skip, limit)

    async def search_apartments(
        self,
        db: Session,
        city: Optional[str] = None,
        district: Optional[str] = None,
        room_count: Optional[int] = None,
        min_price: Optional[int] = None,
        max_price: Optional[int] = None,
        min_area: Optional[float] = None,
        max_area: Optional[float] = None,
        apartment_type_id: Optional[int] = None,
        furnished: Optional[bool] = None,
        balcony: Optional[bool] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[Apartment]:
        """Розширений пошук квартир"""
        return await self.repository.search_apartments(
            db=db, city=city, district=district, room_count=room_count,
            min_price=min_price, max_price=max_price, min_area=min_area,
            max_area=max_area, apartment_type_id=apartment_type_id,
            furnished=furnished, balcony=balcony, skip=skip, limit=limit
        )

    async def get_apartments_by_owner(
        self,
        db: Session,
        owner_id: int,
        skip: int = 0,
        limit: int = 100
    ) -> List[Apartment]:
        """Отримати квартири власника"""
        return await self.repository.get_by_owner(db, owner_id, skip, limit)

    async def get_apartments_by_building(
        self,
        db: Session,
        building_id: int,
        skip: int = 0,
        limit: int = 100
    ) -> List[Apartment]:
        """Отримати квартири в будівлі"""
        return await self.repository.get_by_building(db, building_id, skip, limit)

    async def update_status(
        self,
        db: Session,
        apartment_id: int,
        new_status: ApartmentStatus
    ) -> Optional[Apartment]:
        """Оновити статус квартири"""
        apartment = await self.get_by_id(db, apartment_id)
        if apartment:
            apartment.status = new_status
            db.commit()
            db.refresh(apartment)
        return apartment

    async def calculate_total_value(self, db: Session, owner_id: int) -> int:
        """Розрахувати загальну вартість квартир власника"""
        apartments = await self.get_apartments_by_owner(db, owner_id)
        total_value = sum(apt.sale_price or 0 for apt in apartments)
        return total_value
