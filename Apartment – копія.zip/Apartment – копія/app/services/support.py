from typing import List, Optional
from sqlalchemy.orm import Session
from app.repositories.support_ticket import SupportTicketRepository
from app.schemas.support_ticket import SupportTicketCreate, SupportTicketUpdate, SupportTicketResponse
from app.services.base_service import BaseService


class SupportService(BaseService):
    def __init__(self, db: Session):
        self.db = db
        self.support_repo = SupportTicketRepository(db)

    async def create_ticket(self, ticket_data: SupportTicketCreate) -> SupportTicketResponse:
        """Створити новий тікет підтримки"""
        ticket = await self.support_repo.create(ticket_data)
        return SupportTicketResponse.model_validate(ticket)

    async def get_user_tickets(self, user_email: str) -> List[SupportTicketResponse]:
        """Отримати тікети користувача"""
        tickets = await self.support_repo.get_by_user_email(user_email)
        return [SupportTicketResponse.model_validate(ticket) for ticket in tickets]

    async def update_ticket_status(self, ticket_id: int, status: str, response: Optional[str] = None) -> Optional[
        SupportTicketResponse]:
        """Оновити статус тікета"""
        ticket = await self.support_repo.update_status(ticket_id, status, response)
        if not ticket:
            return None

        return SupportTicketResponse.model_validate(ticket)

    async def assign_ticket(self, ticket_id: int, agent_email: str) -> Optional[SupportTicketResponse]:
        """Призначити тікет агенту"""
        ticket = await self.support_repo.assign_ticket(ticket_id, agent_email)
        if not ticket:
            return None

        return SupportTicketResponse.model_validate(ticket)